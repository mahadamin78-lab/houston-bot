const store = {
  members: new Map(),
  membersLastFetch: 0,
  punishments: new Map(),
  infractions: new Map(),
  promotions: [],
  loaRequests: new Map(),
  shifts: new Map(),
  sessions: new Map(),
  tickets: new Map(),
  ticketCounter: 0,
  afk: new Map(),
  tempBans: new Map(),
  dropdownMenus: new Map(),
  // Applications
  applications: [],
  // Mod Mail: userId -> { threadId, channelId, userId, userTag, status, messages[], date, aiReplies, aiEnabled }
  modmails: new Map(),
};

module.exports = store;
