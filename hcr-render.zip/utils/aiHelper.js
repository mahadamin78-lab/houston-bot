// Smart rule-based AI — no API key required, completely free

const RESPONSES = {
  // Greetings
  greetings: {
    triggers: ['hello', 'hi', 'hey', 'sup', 'yo', 'good morning', 'good evening'],
    responses: [
      'Hello! Welcome to Houston City Roleplay support. How can I help you today?',
      'Hey there! This is HCR support. What can I assist you with?',
      'Hi! Thanks for reaching out to Houston City Roleplay. How can I help?'
    ]
  },
  // Ban appeals
  ban: {
    triggers: ['banned', 'ban appeal', 'unban', 'appeal ban', 'why was i banned', 'i was banned', 'got banned'],
    responses: [
      'To appeal your ban, please provide: 1) Your Discord username 2) The date you were banned 3) Why you believe the ban should be reversed. Staff will review your case shortly.',
      'For ban appeals, we need: your username, ban date, and your explanation. Please provide these details and a staff member will review your case.',
    ]
  },
  // Reports
  report: {
    triggers: ['report', 'reporting', 'reported', 'toxic', 'harassment', 'abusive', 'breaking rules'],
    responses: [
      'To process your report, please provide: 1) The username of the person 2) What happened 3) Any evidence (screenshots or video). Staff will investigate shortly.',
      'Thank you for your report. Please share: the offender\'s username, description of what happened, and any evidence you have.',
    ]
  },
  // Staff report
  staffreport: {
    triggers: ['report staff', 'staff abuse', 'admin abuse', 'abusing power', 'unfair ban', 'corrupt'],
    responses: [
      'Staff reports are handled by Internal Affairs. Please provide: 1) Staff member\'s name 2) What they did 3) Any evidence. This will be escalated to IA immediately.',
      'I\'m escalating this to Internal Affairs. Please describe what happened and provide any evidence you have against the staff member.',
    ]
  },
  // Punishment appeal
  appeal: {
    triggers: ['appeal', 'unfair', 'dispute', 'disagree', 'wrong', 'mistake', 'unjust', 'punish'],
    responses: [
      'To appeal a punishment, please provide: 1) Your username 2) The punishment you received 3) Date it happened 4) Why you believe it was unfair. Staff will review your appeal.',
      'For punishment appeals please share your username, what punishment you received, when it happened, and why you think it should be reversed.',
    ]
  },
  // Rules
  rules: {
    triggers: ['rules', 'what are the rules', 'server rules', 'guidelines', 'rule'],
    responses: [
      'Our main rules are: 1) Respect all members 2) No metagaming 3) Roleplay realistically 4) Follow staff instructions 5) No advertising 6) English only 7) No drama 8) Appropriate content only. Full rules are in our rules channel!',
    ]
  },
  // Roles
  roles: {
    triggers: ['role', 'rank', 'how to get', 'how do i get', 'department', 'join department', 'apply'],
    responses: [
      'To join a department, you need to submit an application on our website or in the applications channel. Available departments: Houston Police Department, Houston County Sheriff\'s Office, and Houston State Police.',
      'You can apply for a department role through our applications system. Check the applications channel or our website for open positions!',
    ]
  },
  // Purchase
  purchase: {
    triggers: ['buy', 'purchase', 'payment', 'paid', 'money', 'refund', 'donation', 'donator'],
    responses: [
      'For purchase related queries, a staff member needs to assist you directly. Please describe your issue and a staff member will be with you shortly. [NEEDS_STAFF]',
    ]
  },
  // Technical
  technical: {
    triggers: ['bug', 'glitch', 'broken', 'not working', 'error', 'issue', 'problem', 'crash', 'lag'],
    responses: [
      'Sorry to hear you\'re having technical issues! Please describe: 1) What happened 2) What you were doing when it occurred 3) Any error messages you saw. Staff will assist you shortly.',
      'For technical issues, please provide as much detail as possible about what happened. A staff member will investigate and help resolve it.',
    ]
  },
  // Whitelist
  whitelist: {
    triggers: ['whitelist', 'white list', 'not whitelisted', 'access', 'cant join', 'can\'t join'],
    responses: [
      'For whitelist access, you need to be a verified member of the community. Please make sure you have read and agreed to the rules. If you believe this is an error, a staff member will check your status.',
    ]
  },
  // General needs staff
  needsStaff: {
    triggers: ['staff', 'admin', 'moderator', 'help me', 'urgent', 'emergency', 'asap', 'please help', 'need help'],
    responses: [
      'I\'ve noted your request and a staff member will be with you shortly. Please describe your issue in detail so we can help you faster. [NEEDS_STAFF]',
      'Notifying staff now. While you wait, please provide as much detail as possible about your issue. [NEEDS_STAFF]',
    ]
  },
  // Default
  default: [
    'Thank you for reaching out to HCR Support! A staff member will be with you shortly. Please describe your issue in as much detail as possible.',
    'Thanks for contacting Houston City Roleplay support. Please explain your issue and a staff member will assist you soon.',
    'Your message has been received! Please provide more details about your issue so our staff can help you effectively.',
  ]
};

function getAIResponse(ticketCategory, conversationHistory) {
  // Get the last user message
  const lastMsg = conversationHistory
    .filter(m => m.authorId !== 'AI')
    .pop();

  const text = lastMsg ? lastMsg.message.toLowerCase() : '';

  // Check category-specific response first
  const categoryResponses = {
    report_member: RESPONSES.report.responses,
    report_staff: RESPONSES.staffreport.responses,
    appeal_punishment: RESPONSES.appeal.responses,
    appeal_infraction: RESPONSES.appeal.responses,
    purchase_query: RESPONSES.purchase.responses,
    server_issues: RESPONSES.technical.responses,
    general_support: null,
    contact_staff: null,
    ask_question: null,
    modmail: null,
  };

  // Try to match triggers
  for (const [key, data] of Object.entries(RESPONSES)) {
    if (key === 'default' || key === 'needsStaff') continue;
    if (data.triggers && data.triggers.some(t => text.includes(t))) {
      const response = data.responses[Math.floor(Math.random() * data.responses.length)];
      const needsStaff = response.includes('[NEEDS_STAFF]');
      return { text: response.replace('[NEEDS_STAFF]', '').trim(), needsStaff };
    }
  }

  // Check if needs staff triggers match
  if (RESPONSES.needsStaff.triggers.some(t => text.includes(t))) {
    const response = RESPONSES.needsStaff.responses[Math.floor(Math.random() * RESPONSES.needsStaff.responses.length)];
    return { text: response.replace('[NEEDS_STAFF]', '').trim(), needsStaff: true };
  }

  // Use category-specific fallback
  if (categoryResponses[ticketCategory]) {
    const responses = categoryResponses[ticketCategory];
    return { text: responses[Math.floor(Math.random() * responses.length)].replace('[NEEDS_STAFF]', '').trim(), needsStaff: ticketCategory === 'purchase_query' };
  }

  // Default response
  const defaults = RESPONSES.default;
  return { text: defaults[Math.floor(Math.random() * defaults.length)], needsStaff: false };
}

module.exports = { getAIResponse };
