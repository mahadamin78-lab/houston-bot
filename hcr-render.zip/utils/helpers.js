const config = require('../config');

function getStaffRole(member) {
  for (const roleId of config.STAFF_ROLES) {
    if (member.roles.cache.has(roleId)) return roleId;
  }
  return null;
}

function isStaff(member) {
  return config.STAFF_ROLES.some(r => member.roles.cache.has(r));
}

function isBodOrOwner(member) {
  return config.BOD_OWNERSHIP.some(r => member.roles.cache.has(r));
}

function isOwnership(member) {
  return member.roles.cache.has(config.ROLES.OWNERSHIP);
}

function getRoleName(roleId) {
  const names = {
    [config.ROLES.MODERATOR]: 'Moderator',
    [config.ROLES.ADMINISTRATOR]: 'Administrator',
    [config.ROLES.INTERNAL_AFFAIRS]: 'Internal Affairs',
    [config.ROLES.MANAGEMENT]: 'Management',
    [config.ROLES.BOARD_OF_DIRECTORS]: 'Board of Directors',
    [config.ROLES.OWNERSHIP]: 'Ownership',
  };
  return names[roleId] || roleId;
}

function formatDuration(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

function formatDate(date) {
  return new Date(date).toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

module.exports = { getStaffRole, isStaff, isBodOrOwner, isOwnership, getRoleName, formatDuration, generateId, formatDate };
