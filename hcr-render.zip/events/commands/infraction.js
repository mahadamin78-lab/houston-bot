const { EmbedBuilder } = require('discord.js');
const config = require('../../config');
const store = require('../../utils/store');
const { generateId, formatDate, isStaff } = require('../../utils/helpers');

module.exports = {
  name: 'infraction',
  async execute(message, args) {
    if (!isStaff(message.member)) return message.reply('❌ You do not have permission.');
    const target = message.mentions.users.first();
    if (!target) return message.reply('Usage: `:infraction @user type reason`');
    const type = args[1];
    const reason = args.slice(2).join(' ');
    if (!type || !reason) return message.reply('Usage: `:infraction @user type reason`');
    const validTypes = ['warning1','warning2','strike1','strike2','suspension','termination','zerotolerance'];
    const typeNorm = type.toLowerCase().replace(/\s/g,'');
    if (!validTypes.includes(typeNorm)) return message.reply(`❌ Invalid type. Valid: ${validTypes.join(', ')}`);
    const userId = target.id;
    if (!store.infractions.has(userId)) store.infractions.set(userId, []);
    const userInfractions = store.infractions.get(userId);
    let finalType = typeNorm;
    const hasZT = userInfractions.some(i => i.type === 'zerotolerance' && !i.revoked);
    if (hasZT && (typeNorm.startsWith('warning') || typeNorm.startsWith('strike'))) {
      finalType = 'suspension';
      await message.channel.send('⚠️ **Zero Tolerance Policy active** — upgraded to **Suspension**.');
    }
    const typeLabels = { warning1:'Warning 1', warning2:'Warning 2', strike1:'Strike 1', strike2:'Strike 2', suspension:'Suspension', termination:'Termination', zerotolerance:'Zero Tolerance Policy' };
    const infraction = { id: generateId(), userId, username: target.tag, type: finalType, typeLabel: typeLabels[finalType], reason, issuedBy: message.author.id, issuedByTag: message.author.tag, date: Date.now(), revoked: false };
    userInfractions.push(infraction);
    const embed = new EmbedBuilder().setTitle('Staff Infraction Issued').setColor('#E8453C').setImage(config.IMAGES.INFRACTIONS)
      .addFields({ name: 'Staff Member', value: `<@${userId}> (${target.tag})`, inline: true }, { name: 'Type', value: infraction.typeLabel, inline: true }, { name: 'Reason', value: reason }, { name: 'Issued By', value: `<@${message.author.id}>`, inline: true }, { name: 'Date', value: formatDate(infraction.date), inline: true }, { name: 'ID', value: `\`${infraction.id}\``, inline: false }).setTimestamp();
    const logChannel = message.guild.channels.cache.get(config.CHANNELS.INFRACTIONS_LOG);
    if (logChannel) await logChannel.send({ embeds: [embed] });
    await message.reply({ embeds: [embed] });
  }
};
