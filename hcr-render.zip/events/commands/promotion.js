const { EmbedBuilder } = require('discord.js');
const config = require('../../config');
const store = require('../../utils/store');
const { generateId, formatDate, isStaff } = require('../../utils/helpers');

module.exports = {
  name: 'promotion',
  async execute(message, args) {
    if (!isStaff(message.member)) return message.reply('❌ No permission.');
    const target = message.mentions.members.first();
    if (!target) return message.reply('Usage: `:promotion @user roleId reason`');
    const roleId = args[1];
    const reason = args.slice(2).join(' ');
    if (!roleId || !reason) return message.reply('Usage: `:promotion @user roleId reason`');
    const role = message.guild.roles.cache.get(roleId);
    if (!role) return message.reply('❌ Role not found.');
    const oldRoles = target.roles.cache.filter(r => config.STAFF_ROLES.includes(r.id)).map(r => ({ id: r.id, name: r.name }));
    try { await target.roles.add(role); } catch (e) { return message.reply('❌ Could not add role. Check bot permissions.'); }
    const promotion = { id: generateId(), userId: target.id, username: target.user.tag, oldRoles, newRoleId: roleId, newRoleName: role.name, promotedBy: message.author.id, promotedByTag: message.author.tag, reason, date: Date.now(), revoked: false };
    store.promotions.push(promotion);
    const embed = new EmbedBuilder().setTitle('Staff Promotion').setColor('#E8453C').setImage(config.IMAGES.PROMOTIONS)
      .addFields({ name: 'Staff Member', value: `<@${target.id}> (${target.user.tag})`, inline: true }, { name: 'New Role', value: role.name, inline: true }, { name: 'Reason', value: reason }, { name: 'Promoted By', value: `<@${message.author.id}>`, inline: true }, { name: 'Date', value: formatDate(promotion.date), inline: true }, { name: 'ID', value: `\`${promotion.id}\``, inline: false }).setTimestamp();
    const logChannel = message.guild.channels.cache.get(config.CHANNELS.PROMOTIONS_LOG);
    if (logChannel) await logChannel.send({ embeds: [embed] });
    await message.reply({ embeds: [embed] });
  }
};
