const store = require('../../utils/store');

module.exports = {
  name: 'afk',
  async execute(message, args) {
    const reason = args.join(' ') || 'AFK';
    store.afk.set(message.author.id, { reason, since: Date.now() });
    await message.reply(`✅ You are now AFK: **${reason}**`);
  }
};
