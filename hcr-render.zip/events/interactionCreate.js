const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const config = require('../config');
const store = require('../utils/store');
const { generateId, formatDate, isStaff } = require('../utils/helpers');
const { getAIResponse } = require('../utils/aiHelper');
const { closeModMail } = require('./modmail');

const CATEGORY_LABELS = {
  general_support: 'General Support', report_member: 'Report Member',
  contact_staff: 'Contact Staff', ask_question: 'Question',
  appeal_punishment: 'Appeal', report_staff: 'Report Staff',
  appeal_infraction: 'Appeal Infraction', report_ia: 'Report IA',
  management_question: 'Management', purchase_query: 'Purchase',
  server_issues: 'Server Issue'
};

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      // Ticket creation
      if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_create') {
        return await handleTicketCreate(interaction, client);
      }

      // Custom dropdown menu reply (from embed builder)
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('custom_menu_')) {
        return await handleCustomMenuSelect(interaction, client);
      }

      // Buttons
      if (interaction.isButton()) {
        const id = interaction.customId;
        if (id === 'ticket_close') return await handleTicketClose(interaction, client);
        if (id === 'ticket_claim') return await handleTicketClaim(interaction, client);
        if (id === 'ticket_adduser') return await handleAddUser(interaction, client);
        if (id === 'ticket_rename') return await handleRename(interaction, client);
        if (id === 'ticket_toggleai') return await handleToggleAI(interaction, client);
        if (id.startsWith('loa_approve_')) return await handleLOAApprove(interaction, client);
        if (id.startsWith('loa_deny_')) return await handleLOADeny(interaction, client);
        if (id.startsWith('mm_close_')) return await handleMMClose(interaction, client);
        if (id.startsWith('mm_toggleai_')) return await handleMMToggleAI(interaction, client);
        if (id.startsWith('mm_claim_')) return await handleMMClaim(interaction, client);
        if (id.startsWith('app_approve_')) return await handleAppApprove(interaction, client);
        if (id.startsWith('webapp_approve_')) return await handleWebAppApprove(interaction, client);
        if (id.startsWith('webapp_deny_')) return await handleWebAppDeny(interaction, client);
        if (id.startsWith('app_deny_')) return await handleAppDeny(interaction, client);
      }
    } catch (e) {
      console.error('Interaction error:', e.message);
      if (!interaction.replied && !interaction.deferred) {
        interaction.reply({ content: '❌ An error occurred.', ephemeral: true }).catch(() => {});
      }
    }
  }
};

async function handleTicketCreate(interaction, client) {
  await interaction.deferReply({ ephemeral: true });
  const category = interaction.values[0];
  const guild = interaction.guild;

  store.ticketCounter++;
  const ticketName = `ticket-${String(store.ticketCounter).padStart(4, '0')}`;

  // Get role objects properly for Discord.js v14
  const permOverwrites = [
    { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
    { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
  ];

  // Add staff roles - fetch them properly
  for (const roleId of config.STAFF_ROLES) {
    const role = guild.roles.cache.get(roleId);
    if (role) permOverwrites.push({ id: role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
  }

  const channel = await guild.channels.create({
    name: ticketName,
    type: ChannelType.GuildText,
    permissionOverwrites: permOverwrites
  });

  const ticket = {
    id: generateId(), channelId: channel.id, name: ticketName, category,
    categoryLabel: CATEGORY_LABELS[category] || category,
    openedBy: interaction.user.id, openedByTag: interaction.user.tag,
    date: Date.now(), status: 'open', claimed: false, claimedBy: null,
    aiEnabled: true, aiReplies: 0, messages: []
  };
  store.tickets.set(channel.id, ticket);

  const embed = new EmbedBuilder()
    .setTitle(`🎫 ${CATEGORY_LABELS[category] || category}`)
    .setDescription(`Hello <@${interaction.user.id}>! Thank you for opening a ticket.\nPlease describe your issue and we'll help you shortly.`)
    .setColor('#E8453C')
    .addFields({ name: 'Category', value: CATEGORY_LABELS[category] || category, inline: true }, { name: 'Ticket ID', value: `\`${ticket.id}\``, inline: true })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Primary).setEmoji('✋'),
    new ButtonBuilder().setCustomId('ticket_adduser').setLabel('Add User').setStyle(ButtonStyle.Secondary).setEmoji('➕'),
    new ButtonBuilder().setCustomId('ticket_rename').setLabel('Rename').setStyle(ButtonStyle.Secondary).setEmoji('✏️'),
    new ButtonBuilder().setCustomId('ticket_toggleai').setLabel('Toggle AI').setStyle(ButtonStyle.Success).setEmoji('🤖')
  );

  await channel.send({ embeds: [embed], components: [row] });

  // AI response after 15 seconds
  setTimeout(async () => {
    const t = store.tickets.get(channel.id);
    if (!t || t.status !== 'open' || !t.aiEnabled || t.claimed || t.aiReplies >= 25) return;
    try {
      const aiResult = await getAIResponse(category, [{ authorId: 'user', message: `I opened a ${CATEGORY_LABELS[category]} ticket.` }]);
      await channel.send(`🤖 **HCR Assistant:** ${aiResult.text}`);
      t.aiReplies++;
      t.messages.push({ authorId: 'AI', authorTag: 'HCR Assistant', message: aiResult.text, timestamp: Date.now() });
      if (aiResult.needsStaff) {
        await channel.send(`🔔 <@&${config.STAFF_SUPPORT_ROLE}> — This ticket requires staff assistance.`);
      }
    } catch (e) { console.error('AI response error:', e.message); }
  }, 15000);

  await interaction.editReply({ content: `✅ Ticket created: <#${channel.id}>` });
}

async function handleCustomMenuSelect(interaction, client) {
  const menuId = interaction.customId.replace('custom_menu_', '');
  const menu = store.dropdownMenus.get(menuId);
  if (!menu) return interaction.reply({ content: '❌ Menu not found.', ephemeral: true });

  const selected = menu.options.find(o => o.value === interaction.values[0]);
  if (!selected) return interaction.reply({ content: '❌ Option not found.', ephemeral: true });

  const replyMsg = selected.reply || `You selected: **${selected.label}**`;
  await interaction.reply({ content: replyMsg });
}

async function handleTicketClose(interaction, client) {
  await interaction.deferReply();
  const ticket = store.tickets.get(interaction.channel.id);
  if (!ticket) return interaction.editReply('❌ Ticket not found.');

  ticket.status = 'closed';
  ticket.closedAt = Date.now();

  const transcript = ticket.messages.map(m => `[${new Date(m.timestamp).toLocaleString()}] ${m.authorTag || m.authorId}: ${m.message}`).join('\n');

  try {
    const user = await client.users.fetch(ticket.openedBy);
    const dm = transcript ? `📋 **Ticket Transcript — ${ticket.name}**\n\`\`\`\n${transcript.slice(0, 1900)}\n\`\`\`` : `📋 Ticket **${ticket.name}** has been closed.`;
    await user.send(dm).catch(() => {});
  } catch (e) {}

  await interaction.editReply('🔒 Ticket closed. Transcript sent to user.');
  setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
}

async function handleTicketClaim(interaction, client) {
  if (!isStaff(interaction.member)) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
  const ticket = store.tickets.get(interaction.channel.id);
  if (!ticket) return interaction.reply({ content: '❌ Not found.', ephemeral: true });
  ticket.claimed = true;
  ticket.claimedBy = interaction.user.id;
  ticket.aiEnabled = false;
  await interaction.reply(`✅ Ticket claimed by <@${interaction.user.id}>. AI disabled.`);
}

async function handleAddUser(interaction, client) {
  if (!isStaff(interaction.member)) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
  await interaction.reply({ content: '📝 Mention the user to add (30s timeout).', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id && m.mentions.users.size > 0;
  const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 30000 }).catch(() => null);
  if (!collected || !collected.size) return;
  const user = collected.first().mentions.users.first();
  await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true });
  await interaction.channel.send(`✅ Added <@${user.id}> to the ticket.`);
}

async function handleRename(interaction, client) {
  if (!isStaff(interaction.member)) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
  await interaction.reply({ content: '📝 Type the new name (30s timeout).', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id;
  const collected = await interaction.channel.awaitMessages({ filter, max: 1, time: 30000 }).catch(() => null);
  if (!collected || !collected.size) return;
  const newName = collected.first().content.toLowerCase().replace(/\s+/g, '-').slice(0, 100);
  await interaction.channel.setName(newName);
  await interaction.channel.send(`✅ Renamed to **${newName}**.`);
}

async function handleToggleAI(interaction, client) {
  if (!isStaff(interaction.member)) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
  const ticket = store.tickets.get(interaction.channel.id);
  if (!ticket) return interaction.reply({ content: '❌ Not found.', ephemeral: true });
  ticket.aiEnabled = !ticket.aiEnabled;
  await interaction.reply(`🤖 AI is now **${ticket.aiEnabled ? 'enabled' : 'disabled'}**.`);
}

async function handleLOAApprove(interaction, client) {
  if (!config.BOD_OWNERSHIP.some(r => interaction.member.roles.cache.has(r))) return interaction.reply({ content: '❌ BOD/Ownership only.', ephemeral: true });
  const userId = interaction.customId.split('_')[2];
  const loa = store.loaRequests.get(userId);
  if (!loa) return interaction.reply({ content: '❌ LOA not found.', ephemeral: true });
  loa.status = 'approved';
  try {
    const member = await interaction.guild.members.fetch(userId);
    const loaRole = interaction.guild.roles.cache.get(config.ROLES.LOA);
    if (loaRole) await member.roles.add(loaRole);
  } catch (e) {}
  await interaction.reply(`✅ LOA approved for <@${userId}>.`);
}

async function handleLOADeny(interaction, client) {
  if (!config.BOD_OWNERSHIP.some(r => interaction.member.roles.cache.has(r))) return interaction.reply({ content: '❌ BOD/Ownership only.', ephemeral: true });
  const userId = interaction.customId.split('_')[2];
  const loa = store.loaRequests.get(userId);
  if (!loa) return interaction.reply({ content: '❌ LOA not found.', ephemeral: true });
  loa.status = 'denied';
  await interaction.reply(`❌ LOA denied for <@${userId}>.`);
}

// Add modmail button handling at bottom of execute function - patch

async function handleMMClose(interaction, client) {
  const userId = interaction.customId.replace('mm_close_', '');
  const mm = store.modmails.get(userId);
  if (!mm) return interaction.reply({ content: '❌ ModMail not found.', ephemeral: true });
  await closeModMail(userId, mm, client, interaction.user.tag);
  try { const user = await client.users.fetch(userId); await user.send('🔒 Your mod mail has been closed by staff. DM again anytime if you need help!'); } catch(e){}
  await interaction.reply('🔒 Mod mail closed.');
}

async function handleMMToggleAI(interaction, client) {
  const userId = interaction.customId.replace('mm_toggleai_', '');
  const mm = store.modmails.get(userId);
  if (!mm) return interaction.reply({ content: '❌ Not found.', ephemeral: true });
  mm.aiEnabled = !mm.aiEnabled;
  await interaction.reply(`🤖 AI is now **${mm.aiEnabled ? 'enabled' : 'disabled'}** for this mod mail.`);
}

async function handleMMClaim(interaction, client) {
  const userId = interaction.customId.replace('mm_claim_', '');
  const mm = store.modmails.get(userId);
  if (!mm) return interaction.reply({ content: '❌ Not found.', ephemeral: true });
  mm.claimedBy = interaction.user.id;
  mm.aiEnabled = false;
  await interaction.reply(`✅ Claimed by <@${interaction.user.id}>. AI disabled.`);
}

async function handleAppApprove(interaction, client) {
  const appId = interaction.customId.replace('app_approve_', '');
  const app = store.applications.find(a => a.id === appId);
  if (!app) return interaction.reply({ content: '❌ Application not found.', ephemeral: true });
  if (app.status !== 'pending') return interaction.reply({ content: '❌ Already reviewed.', ephemeral: true });

  await interaction.reply({ content: '📝 Enter the reason for approval (60s):', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id;
  const collected = await interaction.channel?.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
  const reason = collected?.first()?.content || 'No reason provided';

  app.status = 'approved';
  app.reviewedBy = interaction.user.id;
  app.reviewReason = reason;
  app.reviewDate = Date.now();

  try {
    const user = await client.users.fetch(app.userId);
    const embed = new EmbedBuilder()
      .setTitle('✅ BOD Application Approved')
      .setColor('#22c55e')
      .setDescription(`Congratulations <@${app.userId}>! Your Board of Directors application has been **approved**!`)
      .addFields(
        { name: 'Reviewed By', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();
    await user.send({ embeds: [embed] });
  } catch(e) {}

  await interaction.followUp({ content: `✅ Application approved. Applicant has been notified.`, ephemeral: true });
}

async function handleAppDeny(interaction, client) {
  const appId = interaction.customId.replace('app_deny_', '');
  const app = store.applications.find(a => a.id === appId);
  if (!app) return interaction.reply({ content: '❌ Application not found.', ephemeral: true });
  if (app.status !== 'pending') return interaction.reply({ content: '❌ Already reviewed.', ephemeral: true });

  await interaction.reply({ content: '📝 Enter the reason for denial (60s):', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id;
  const collected = await interaction.channel?.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
  const reason = collected?.first()?.content || 'No reason provided';

  app.status = 'denied';
  app.reviewedBy = interaction.user.id;
  app.reviewReason = reason;
  app.reviewDate = Date.now();

  try {
    const user = await client.users.fetch(app.userId);
    const embed = new EmbedBuilder()
      .setTitle('❌ BOD Application Denied')
      .setColor('#E8453C')
      .setDescription(`Thank you for applying <@${app.userId}>. Unfortunately your Board of Directors application has been **denied**.`)
      .addFields(
        { name: 'Reviewed By', value: `<@${interaction.user.id}>`, inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();
    await user.send({ embeds: [embed] });
  } catch(e) {}

  await interaction.followUp({ content: `❌ Application denied. Applicant has been notified.`, ephemeral: true });
}

async function handleWebAppApprove(interaction, client) {
  const appId = interaction.customId.replace('webapp_approve_', '');
  const app = store.applications.find(a => a.id === appId);
  if (!app) return interaction.reply({ content: '❌ Application not found.', ephemeral: true });
  if (app.status !== 'pending') return interaction.reply({ content: '❌ Already reviewed.', ephemeral: true });

  await interaction.reply({ content: '📝 Type your reason for approval (60s):', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id;
  const collected = await interaction.channel?.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
  const reason = collected?.first()?.content || 'No reason provided';

  app.status = 'approved';
  app.reviewedBy = interaction.user.tag;
  app.reviewReason = reason;

  const embed = new EmbedBuilder()
    .setTitle('✅ Application Approved')
    .setColor('#22c55e')
    .setDescription('Your **' + app.department + '** application has been **approved**! Welcome to the team.')
    .addFields({ name: 'Reviewed By', value: interaction.user.tag, inline: true }, { name: 'Reason', value: reason })
    .setTimestamp();

  // Try DM if userId known
  if (app.userId) {
    try { const user = await client.users.fetch(app.userId); await user.send({ embeds: [embed] }); } catch(e) {}
  }

  await interaction.followUp({ content: `✅ Application **${appId}** approved!`, ephemeral: true });
  await interaction.message.edit({ components: [] }).catch(() => {});
}

async function handleWebAppDeny(interaction, client) {
  const appId = interaction.customId.replace('webapp_deny_', '');
  const app = store.applications.find(a => a.id === appId);
  if (!app) return interaction.reply({ content: '❌ Application not found.', ephemeral: true });
  if (app.status !== 'pending') return interaction.reply({ content: '❌ Already reviewed.', ephemeral: true });

  await interaction.reply({ content: '📝 Type your reason for denial (60s):', ephemeral: true });
  const filter = m => m.author.id === interaction.user.id;
  const collected = await interaction.channel?.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
  const reason = collected?.first()?.content || 'No reason provided';

  app.status = 'denied';
  app.reviewedBy = interaction.user.tag;
  app.reviewReason = reason;

  await interaction.followUp({ content: `❌ Application **${appId}** denied.`, ephemeral: true });
  await interaction.message.edit({ components: [] }).catch(() => {});
}
