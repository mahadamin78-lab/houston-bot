const config = require('../config');
const store = require('../utils/store');
const { ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const modmail = require('./modmail');

const commands = new Map();
const cmdPath = path.join(__dirname, 'commands');
fs.readdirSync(cmdPath).filter(f => f.endsWith('.js')).forEach(file => {
  const cmd = require(path.join(cmdPath, file));
  commands.set(cmd.name, cmd);
});

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot) return;

    // DM handling (ModMail)
    if (message.channel.type === ChannelType.DM) {
      if (message.content.toLowerCase().trim() === 'close') {
        await modmail.handleUserClose(message, client);
        return;
      }
      await modmail.handleDM(message, client);
      return;
    }

    if (!message.guild) return;

    // AFK removal
    if (store.afk.has(message.author.id)) {
      store.afk.delete(message.author.id);
      message.reply('✅ Welcome back! Your AFK has been removed.')
        .then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
    }

    // AFK ping detection
    if (message.mentions.users.size > 0) {
      message.mentions.users.forEach(user => {
        if (store.afk.has(user.id)) {
          const d = store.afk.get(user.id);
          const mins = Math.floor((Date.now() - d.since) / 60000);
          message.reply(`💤 **${user.username}** is AFK: ${d.reason} *(${mins}m ago)*`);
        }
      });
    }

    // Store message in ticket
    const ticket = store.tickets.get(message.channel.id);
    if (ticket && ticket.status === 'open') {
      ticket.messages.push({ authorId: message.author.id, authorTag: message.author.tag, message: message.content, timestamp: Date.now() });
      const humanKeywords = ['i need a human', 'need staff', 'real person', 'speak to someone', 'get me staff'];
      if (humanKeywords.some(k => message.content.toLowerCase().includes(k))) {
        await message.channel.send(`🔔 <@&${config.STAFF_SUPPORT_ROLE}> — A user is requesting human assistance!`);
        return;
      }
    }

    // ModMail thread relay
    let isModMailThread = false;
    for (const [, mm] of store.modmails) {
      if (mm.channelId === message.channel.id && mm.status === 'open') { isModMailThread = true; break; }
    }
    if (isModMailThread) {
      await modmail.handleThreadMessage(message, client);
      return;
    }

    // Prefix commands
    if (!message.content.startsWith(config.PREFIX)) return;
    const args = message.content.slice(config.PREFIX.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();
    const command = commands.get(commandName);
    if (!command) return;
    try { await command.execute(message, args, client); }
    catch (err) { console.error(`Command error [${commandName}]:`, err); message.reply('❌ An error occurred.').catch(() => {}); }
  }
};
