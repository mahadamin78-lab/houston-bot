const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');
const store = require('../utils/store');
const cron = require('node-cron');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    await setupTicketPanel(client);
    setupCronJobs(client);
  }
};

async function setupTicketPanel(client) {
  try {
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const channel = guild.channels.cache.get(config.CHANNELS.TICKET_PANEL);
    if (!channel) return console.log('⚠️ Ticket panel channel not found');
    const messages = await channel.messages.fetch({ limit: 10 });
    const existing = messages.find(m => m.author.id === client.user.id && m.components.length > 0);
    if (existing) return console.log('✅ Ticket panel already exists');
    const embed = new EmbedBuilder()
      .setTitle('🎫 Houston City Roleplay Support')
      .setDescription('Need help? Open a ticket using the menu below.')
      .setColor('#E8453C')
      .setFooter({ text: 'Houston City Roleplay' });
    const menu = new StringSelectMenuBuilder()
      .setCustomId('ticket_create')
      .setPlaceholder('Select a ticket category...')
      .addOptions([
        { label: 'General Support', value: 'general_support', description: 'General questions or help', emoji: '💬' },
        { label: 'Report a Member', value: 'report_member', description: 'Report a community member', emoji: '🚨' },
        { label: 'Contact Staff', value: 'contact_staff', description: 'Reach out to staff directly', emoji: '👮' },
        { label: 'Ask a Question', value: 'ask_question', description: 'Have a quick question?', emoji: '❓' },
        { label: 'Appeal Punishment', value: 'appeal_punishment', description: 'Appeal a ban or punishment', emoji: '⚖️' },
        { label: 'Report Staff (IA)', value: 'report_staff', description: 'Report a staff member to IA', emoji: '🔍' },
        { label: 'Appeal Infraction (IA)', value: 'appeal_infraction', description: 'Appeal a staff infraction', emoji: '📋' },
        { label: 'Report IA (Management)', value: 'report_ia', description: 'Report Internal Affairs', emoji: '📢' },
        { label: 'Management Question', value: 'management_question', description: 'Speak with Management', emoji: '🏢' },
        { label: 'Purchase Query', value: 'purchase_query', description: 'Questions about purchases', emoji: '💳' },
        { label: 'Server Issues', value: 'server_issues', description: 'Technical server issues', emoji: '⚙️' },
      ]);
    await channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
    console.log('✅ Ticket panel created');
  } catch (e) { console.error('Ticket panel error:', e.message); }
}

function setupCronJobs(client) {
  cron.schedule('* * * * *', async () => {
    const now = Date.now();
    for (const [userId, ban] of store.tempBans) {
      if (now >= ban.expiresAt) {
        try {
          const guild = await client.guilds.fetch(config.GUILD_ID);
          await guild.bans.remove(userId).catch(() => {});
          store.tempBans.delete(userId);
        } catch (e) {}
      }
    }
  });
  cron.schedule('59 23 * * 5', async () => {
    try {
      const guild = await client.guilds.fetch(config.GUILD_ID);
      await guild.members.fetch();
      for (const [userId, shift] of store.shifts) {
        if (shift.suspended) { shift.weeklyMinutes = 0; shift.suspended = false; continue; }
        const member = guild.members.cache.get(userId);
        if (!member) continue;
        if (member.roles.cache.has(config.ROLES.LOA)) { shift.weeklyMinutes = 0; continue; }
        const staffRoleId = config.STAFF_ROLES.find(r => member.roles.cache.has(r));
        if (!staffRoleId) continue;
        let quota = config.WEEKLY_QUOTAS[staffRoleId] || 0;
        if (member.roles.cache.has(config.ROLES.REDUCED_ACTIVITY)) quota = Math.floor(quota / 2);
        if (quota > 0 && (shift.weeklyMinutes || 0) < quota) await member.roles.add(config.ROLES.ACTIVITY_WARNING).catch(() => {});
        shift.weeklyMinutes = 0;
      }
    } catch (e) { console.error('Weekly check error:', e); }
  });
  cron.schedule('*/5 * * * *', async () => {
    try {
      const guild = await client.guilds.fetch(config.GUILD_ID);
      const members = await guild.members.fetch();
      store.members.clear();
      members.forEach(m => store.members.set(m.id, m));
      store.membersLastFetch = Date.now();
    } catch (e) {}
  });
}
