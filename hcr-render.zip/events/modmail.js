const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const config = require('../config');
const store = require('../utils/store');
const { generateId, formatDate } = require('../utils/helpers');
const { getAIResponse } = require('../utils/aiHelper');

module.exports = {
  name: 'modmail',

  async handleDM(message, client) {
    if (message.author.bot) return;
    if (message.channel.type !== ChannelType.DM) return;
    const userId = message.author.id;
    const existing = store.modmails.get(userId);

    if (existing && existing.status === 'open') {
      try {
        const guild = await client.guilds.fetch(config.GUILD_ID);
        const thread = guild.channels.cache.get(existing.channelId) ||
          await guild.channels.fetch(existing.channelId).catch(() => null);
        if (thread) {
          existing.messages.push({ authorId: userId, authorTag: message.author.tag, message: message.content, timestamp: Date.now(), from: 'user' });
          const embed = new EmbedBuilder()
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
            .setDescription(message.content)
            .setColor('#E8453C')
            .setFooter({ text: 'User Message' })
            .setTimestamp();
          await thread.send({ embeds: [embed] });

          if (existing.aiEnabled && existing.aiReplies < 25) {
            setTimeout(async () => {
              const mm = store.modmails.get(userId);
              if (!mm || mm.status !== 'open' || !mm.aiEnabled) return;
              try {
                const aiResult = await getAIResponse('modmail', mm.messages.filter(m => m.from === 'user').map(m => ({ authorId: 'user', message: m.message })));
                mm.aiReplies++;
                mm.messages.push({ authorId: 'AI', authorTag: 'HCR Assistant', message: aiResult.text, timestamp: Date.now(), from: 'staff' });
                await message.author.send(`🤖 **HCR Assistant:** ${aiResult.text}`);
                const aiEmbed = new EmbedBuilder().setAuthor({ name: 'HCR Assistant (AI)' }).setDescription(aiResult.text).setColor('#3b82f6').setFooter({ text: 'AI Response' }).setTimestamp();
                await thread.send({ embeds: [aiEmbed] });
                if (aiResult.needsStaff) await thread.send(`🔔 <@&${config.STAFF_SUPPORT_ROLE}> — AI could not resolve this. Manual assistance needed.`);
              } catch (e) { console.error('ModMail AI error:', e.message); }
            }, 8000);
          }
        }
      } catch (e) { console.error('ModMail relay error:', e.message); }
      return;
    }

    try {
      const guild = await client.guilds.fetch(config.GUILD_ID);
      const modmailChannel = guild.channels.cache.get(config.CHANNELS.MODMAIL);
      if (!modmailChannel) return console.error('ModMail channel not found');

      const thread = await modmailChannel.threads.create({
        name: `modmail-${message.author.username}-${Date.now().toString(36)}`,
        autoArchiveDuration: 1440,
        reason: `ModMail from ${message.author.tag}`
      });

      const modmail = {
        id: generateId(), channelId: thread.id, userId,
        userTag: message.author.tag, userAvatar: message.author.displayAvatarURL(),
        status: 'open', date: Date.now(), aiEnabled: true, aiReplies: 0,
        messages: [{ authorId: userId, authorTag: message.author.tag, message: message.content, timestamp: Date.now(), from: 'user' }]
      };
      store.modmails.set(userId, modmail);

      const openEmbed = new EmbedBuilder()
        .setTitle('📬 New Mod Mail')
        .setColor('#E8453C')
        .setThumbnail(message.author.displayAvatarURL())
        .addFields(
          { name: 'User', value: `<@${userId}> (${message.author.tag})`, inline: true },
          { name: 'User ID', value: userId, inline: true },
          { name: 'First Message', value: message.content }
        )
        .setFooter({ text: `ModMail ID: ${modmail.id}` })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`mm_close_${userId}`).setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
        new ButtonBuilder().setCustomId(`mm_toggleai_${userId}`).setLabel('Toggle AI').setStyle(ButtonStyle.Primary).setEmoji('🤖'),
        new ButtonBuilder().setCustomId(`mm_claim_${userId}`).setLabel('Claim').setStyle(ButtonStyle.Success).setEmoji('✋')
      );

      await thread.send({ embeds: [openEmbed], components: [row] });
      await thread.send(`<@&${config.STAFF_SUPPORT_ROLE}> — New mod mail received!`);

      const userEmbed = new EmbedBuilder()
        .setTitle('📬 Houston City Roleplay — Mod Mail')
        .setDescription('Your message has been received! Our staff will get back to you shortly.\n\nYou can continue sending messages here and they\'ll be forwarded to our team.')
        .setColor('#E8453C')
        .setFooter({ text: 'Type "close" to close your mod mail at any time' })
        .setTimestamp();
      await message.author.send({ embeds: [userEmbed] });

      setTimeout(async () => {
        const mm = store.modmails.get(userId);
        if (!mm || !mm.aiEnabled) return;
        try {
          const aiResult = await getAIResponse('modmail', [{ authorId: 'user', message: message.content }]);
          mm.aiReplies++;
          mm.messages.push({ authorId: 'AI', authorTag: 'HCR Assistant', message: aiResult.text, timestamp: Date.now(), from: 'staff' });
          await message.author.send(`🤖 **HCR Assistant:** ${aiResult.text}`);
          const aiEmbed = new EmbedBuilder().setAuthor({ name: 'HCR Assistant (AI)' }).setDescription(aiResult.text).setColor('#3b82f6').setFooter({ text: 'AI Response' }).setTimestamp();
          await thread.send({ embeds: [aiEmbed] });
          if (aiResult.needsStaff) await thread.send(`🔔 <@&${config.STAFF_SUPPORT_ROLE}> — AI could not resolve this.`);
        } catch (e) {}
      }, 8000);

    } catch (e) { console.error('ModMail create error:', e.message); }
  },

  async handleThreadMessage(message, client) {
    if (message.author.bot) return;
    let modmail = null, mmUserId = null;
    for (const [uid, mm] of store.modmails) {
      if (mm.channelId === message.channelId && mm.status === 'open') { modmail = mm; mmUserId = uid; break; }
    }
    if (!modmail) return;
    modmail.messages.push({ authorId: message.author.id, authorTag: message.author.tag, message: message.content, timestamp: Date.now(), from: 'staff' });
    try {
      const user = await client.users.fetch(mmUserId);
      const embed = new EmbedBuilder()
        .setAuthor({ name: `${message.author.tag} — HCR Staff`, iconURL: message.author.displayAvatarURL() })
        .setDescription(message.content)
        .setColor('#22c55e')
        .setFooter({ text: 'Houston City Roleplay Staff' })
        .setTimestamp();
      await user.send({ embeds: [embed] });
    } catch (e) { await message.reply('⚠️ Could not send message to user — they may have DMs disabled.'); }
  },

  async handleUserClose(message, client) {
    const userId = message.author.id;
    const modmail = store.modmails.get(userId);
    if (!modmail || modmail.status !== 'open') return;
    if (message.content.toLowerCase().trim() !== 'close') return;
    await closeModMail(userId, modmail, client, 'User');
    await message.author.send('✅ Your mod mail has been closed. Feel free to DM again if you need further help!');
  }
};

async function closeModMail(userId, modmail, client, closedBy) {
  modmail.status = 'closed';
  modmail.closedAt = Date.now();
  try {
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const thread = guild.channels.cache.get(modmail.channelId);
    if (thread) {
      const closeEmbed = new EmbedBuilder()
        .setTitle('🔒 Mod Mail Closed')
        .setColor('#888')
        .addFields({ name: 'Closed By', value: closedBy }, { name: 'Duration', value: `${Math.floor((Date.now() - modmail.date) / 60000)} minutes` })
        .setTimestamp();
      await thread.send({ embeds: [closeEmbed] });
      await thread.setArchived(true).catch(() => {});
    }
  } catch (e) {}
}

module.exports.closeModMail = closeModMail;
