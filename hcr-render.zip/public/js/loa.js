async function loadLOA() {
  try {
    const loas = await api('GET', '/loa');
    const tbody = document.getElementById('loa-tbody');
    if (!loas.length) { tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state"><h3>No LOA requests</h3></div></td></tr>'; return; }
    tbody.innerHTML = loas.map(l => `
      <tr>
        <td><div style="font-weight:600">${l.username || l.userId}</div></td>
        <td style="max-width:200px;font-size:13px">${l.reason}</td>
        <td style="font-size:12px">${l.startDate}</td>
        <td style="font-size:12px">${l.endDate}</td>
        <td style="font-size:12px;color:var(--text-muted)">${formatDate(l.date)}</td>
        <td><span class="badge ${l.status === 'approved' ? 'badge-green' : l.status === 'denied' ? 'badge-red' : 'badge-yellow'}">${l.status}</span></td>
      </tr>`).join('');
  } catch (e) { toast(e.message, 'error'); }
}

function openLOAForm() {
  openModal('Submit LOA Request', `
    <div class="form-group"><label class="form-label">Reason</label><textarea class="form-textarea" id="loa-reason" placeholder="Reason for leave..."></textarea></div>
    <div class="form-group"><label class="form-label">Start Date</label><input type="date" class="form-input" id="loa-start"></div>
    <div class="form-group"><label class="form-label">End Date</label><input type="date" class="form-input" id="loa-end"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitLOA()">Submit LOA</button>
    </div>`);
}

async function submitLOA() {
  const reason = document.getElementById('loa-reason').value;
  const startDate = document.getElementById('loa-start').value;
  const endDate = document.getElementById('loa-end').value;
  if (!reason || !startDate || !endDate) return toast('Fill all fields', 'error');
  try {
    await api('POST', '/loa', { reason, startDate, endDate });
    toast('LOA submitted! Check the LOA channel.', 'success');
    closeModal();
    loadLOA();
  } catch (e) { toast(e.message, 'error'); }
}

loadLOA();
