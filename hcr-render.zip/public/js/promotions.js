let allPromos = [];

async function loadPromotions() {
  try {
    allPromos = await api('GET', '/promotions');
    renderPromotions();
  } catch (e) { toast(e.message, 'error'); }
}

function renderPromotions() {
  const search = document.getElementById('promo-search').value.toLowerCase();
  const tbody = document.getElementById('promotions-tbody');
  const filtered = allPromos.filter(p =>
    (p.username || '').toLowerCase().includes(search) ||
    (p.newRoleName || '').toLowerCase().includes(search)
  );
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><h3>No promotions found</h3></div></td></tr>'; return; }
  tbody.innerHTML = filtered.map(p => `
    <tr style="${p.revoked ? 'opacity:0.5' : ''}">
      <td><div style="font-weight:600">${p.username || p.userId}</div><div style="font-size:11px;color:var(--text-muted)">${p.userId}</div></td>
      <td><span class="badge badge-green">${p.newRoleName}</span></td>
      <td style="font-size:12px;color:var(--text-muted)">${p.promotedByTag || p.promotedBy}</td>
      <td style="max-width:180px;font-size:13px">${p.reason}</td>
      <td style="font-size:12px;color:var(--text-muted)">${formatDate(p.date)}</td>
      <td><span class="badge ${p.revoked ? 'badge-gray' : 'badge-green'}">${p.revoked ? 'Revoked' : 'Active'}</span></td>
      <td>${!p.revoked ? `<button class="btn btn-danger btn-sm" onclick="revokePromotion('${p.id}')">Revoke</button>` : '—'}</td>
    </tr>`).join('');
}

async function revokePromotion(id) {
  const ok = await confirmModal('Revoke Promotion', '<p>This will remove the promoted role and restore the previous role. Continue?</p>');
  if (!ok) return;
  try { await api('POST', `/promotions/${id}/revoke`); toast('Promotion revoked', 'success'); loadPromotions(); }
  catch (e) { toast(e.message, 'error'); }
}

document.getElementById('promo-search').addEventListener('input', renderPromotions);
loadPromotions();
