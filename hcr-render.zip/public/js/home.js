(async () => {
  try {
    const stats = await api('GET', '/stats');
    document.getElementById('stat-members').textContent = stats.members.toLocaleString();
    document.getElementById('stat-staff').textContent = stats.activeStaff;
    document.getElementById('stat-tickets').textContent = stats.openTickets;
    document.getElementById('stat-sessions').textContent = stats.activeSessions;
  } catch (e) {}

  try {
    const infs = await api('GET', '/infractions');
    const el = document.getElementById('recent-infractions');
    const recent = infs.filter(i => !i.revoked).slice(0, 5);
    if (!recent.length) { empty(el, 'No infractions yet'); return; }
    el.innerHTML = recent.map(i => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-weight:600;font-size:13px">${i.username || i.userId}</div>
          <div style="font-size:11px;color:var(--text-muted)">${i.typeLabel} — ${i.reason?.slice(0,40)}</div>
        </div>
        <span class="badge badge-red">${i.typeLabel}</span>
      </div>`).join('');
  } catch (e) {}

  try {
    const promos = await api('GET', '/promotions');
    const el = document.getElementById('recent-promotions');
    const recent = promos.filter(p => !p.revoked).slice(0, 5);
    if (!recent.length) { empty(el, 'No promotions yet'); return; }
    el.innerHTML = recent.map(p => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
        <div>
          <div style="font-weight:600;font-size:13px">${p.username || p.userId}</div>
          <div style="font-size:11px;color:var(--text-muted)">→ ${p.newRoleName}</div>
        </div>
        <span class="badge badge-green">Promoted</span>
      </div>`).join('');
  } catch (e) {}
})();
