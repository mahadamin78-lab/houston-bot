// Global utility functions

async function api(method, url, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch('/api' + url, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function toast(msg, type = 'info') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type} show`;
  setTimeout(() => t.className = 'toast', 3000);
}

function openModal(title, bodyHTML, onConfirm) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHTML;
  document.getElementById('modal-overlay').classList.remove('hidden');
  window._modalConfirm = onConfirm;
}

function closeModal() {
  document.getElementById('modal-overlay').classList.add('hidden');
  window._modalConfirm = null;
}

function confirmModal(title, bodyHTML) {
  return new Promise((resolve) => {
    const footer = `<div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal(); window._modalResolve(false)">Cancel</button>
      <button class="btn btn-primary" onclick="closeModal(); window._modalResolve(true)">Confirm</button>
    </div>`;
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = bodyHTML + footer;
    document.getElementById('modal-overlay').classList.remove('hidden');
    window._modalResolve = resolve;
  });
}

function formatDate(ts) {
  return new Date(ts).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function formatDuration(mins) {
  const h = Math.floor(mins / 60), m = mins % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

function loading(el) {
  el.innerHTML = `<div class="loading"><div class="spinner"></div>Loading...</div>`;
}

function empty(el, msg = 'No data found') {
  el.innerHTML = `<div class="empty-state"><h3>Nothing here</h3><p>${msg}</p></div>`;
}

// Close modal on overlay click
document.getElementById('modal-overlay')?.addEventListener('click', (e) => {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
});
