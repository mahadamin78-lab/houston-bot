const QUESTIONS = [
  // Basic Info
  { id: 'q1', label: 'What is your in-game username and Discord tag?', placeholder: 'e.g. JohnDoe | JohnDoe#0001' },
  { id: 'q2', label: 'What is your current rank and how long have you held it?', placeholder: 'e.g. Administrator for 3 months' },
  { id: 'q3', label: 'How long have you been a member of Houston City Roleplay?', placeholder: 'e.g. 8 months' },
  { id: 'q4', label: 'What is your age?', placeholder: 'e.g. 18' },
  { id: 'q5', label: 'What timezone are you in?', placeholder: 'e.g. EST, GMT, PST' },
  // Experience
  { id: 'q6', label: 'What previous leadership or management experience do you have?', placeholder: 'Describe your experience...' },
  { id: 'q7', label: 'Have you held a high rank in any other Discord communities?', placeholder: 'Yes/No — if yes, describe...' },
  { id: 'q8', label: 'What skills do you bring to the Board of Directors?', placeholder: 'List your key skills...' },
  { id: 'q9', label: 'Describe your most significant contribution to HCR so far.', placeholder: 'Your biggest achievement...' },
  { id: 'q10', label: 'How long have you been in a staff role total?', placeholder: 'e.g. 1 year across all roles' },
  // Scenarios
  { id: 'q11', label: 'A staff member is repeatedly breaking rules but is popular. How do you handle it?', placeholder: 'Describe your approach...' },
  { id: 'q12', label: 'Two senior staff are in a major conflict. What steps do you take?', placeholder: 'Describe your steps...' },
  { id: 'q13', label: 'A community member accuses a staff member of abuse. What do you do?', placeholder: 'Describe your process...' },
  { id: 'q14', label: 'The server is losing members rapidly. What is your action plan?', placeholder: 'Describe your plan...' },
  { id: 'q15', label: 'A staff member leaks internal information. How do you respond?', placeholder: 'Describe your response...' },
  // Commitment
  { id: 'q16', label: 'How many hours per week can you dedicate to BOD duties?', placeholder: 'e.g. 10-15 hours' },
  { id: 'q17', label: 'Do you have any upcoming commitments that may affect activity?', placeholder: 'Yes/No — if yes, explain...' },
  { id: 'q18', label: 'Have you ever been warned, struck or suspended? If yes explain.', placeholder: 'Yes/No — if yes, explain...' },
  { id: 'q19', label: 'Have you ever left HCR or gone inactive for a long period? Why?', placeholder: 'Yes/No — if yes, explain...' },
  { id: 'q20', label: 'Are you currently in any other server staff teams?', placeholder: 'Yes/No — if yes, which ones?' },
  // Final
  { id: 'q21', label: 'Why do you want to be on the Board of Directors specifically?', placeholder: 'Be specific and honest...' },
  { id: 'q22', label: 'What improvements would you make to HCR as a BOD member?', placeholder: 'Your ideas and vision...' },
  { id: 'q23', label: 'How would you describe your leadership style?', placeholder: 'e.g. Democratic, firm but fair...' },
  { id: 'q24', label: 'What does Board of Directors mean to you?', placeholder: 'In your own words...' },
  { id: 'q25', label: 'Is there anything else you want Ownership to know?', placeholder: 'Any additional information...' },
];

let allApplications = [];

async function loadApplications() {
  try {
    allApplications = await api('GET', '/applications');
    renderApplications();
  } catch(e) { toast(e.message, 'error'); }
}

function renderApplications() {
  const el = document.getElementById('applications-list');
  if (!allApplications.length) {
    empty(el, 'No applications submitted yet.');
    return;
  }
  el.innerHTML = `
    <div class="table-wrapper">
      <table>
        <thead>
          <tr><th>Applicant</th><th>Submitted</th><th>Status</th><th>Action</th></tr>
        </thead>
        <tbody>
          ${allApplications.map(a => `
            <tr>
              <td><div style="font-weight:600">${a.username}</div><div style="font-size:11px;color:var(--text-muted)">${a.userId}</div></td>
              <td style="font-size:12px;color:var(--text-muted)">${formatDate(a.date)}</td>
              <td><span class="badge ${a.status === 'pending' ? 'badge-yellow' : a.status === 'approved' ? 'badge-green' : 'badge-red'}">${a.status}</span></td>
              <td><button class="btn btn-info btn-sm" onclick="viewApplication('${a.id}')">View</button></td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
}

function openApplication() {
  const formHTML = `
    <div style="max-height:60vh;overflow-y:auto;padding-right:8px">
      <p style="color:var(--text-muted);font-size:13px;margin-bottom:16px">Please answer all questions honestly and thoroughly. Your application will be reviewed by Ownership.</p>
      ${QUESTIONS.map((q, i) => `
        <div class="form-group">
          <label class="form-label" style="color:var(--text);font-size:13px">${i + 1}. ${q.label}</label>
          <textarea class="form-textarea" id="${q.id}" placeholder="${q.placeholder}" style="min-height:70px"></textarea>
        </div>`).join('')}
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="submitApplication()">Submit Application</button>
    </div>`;

  openModal('Board of Directors Application', formHTML);
}

async function submitApplication() {
  const answers = {};
  let allFilled = true;

  QUESTIONS.forEach(q => {
    const val = document.getElementById(q.id)?.value?.trim();
    if (!val) allFilled = false;
    answers[q.id] = { question: q.label, answer: val || '' };
  });

  if (!allFilled) return toast('Please answer all questions before submitting.', 'error');

  try {
    await api('POST', '/applications', { answers });
    toast('Application submitted! Ownership will review it shortly. ✅', 'success');
    closeModal();
    loadApplications();
  } catch(e) { toast(e.message, 'error'); }
}

async function viewApplication(id) {
  const app = allApplications.find(a => a.id === id);
  if (!app) return;

  const answersHTML = Object.values(app.answers).map((a, i) => `
    <div style="margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid var(--border)">
      <div style="font-size:12px;font-weight:700;color:var(--primary);margin-bottom:4px">${i+1}. ${a.question}</div>
      <div style="font-size:13px;color:var(--text)">${a.answer || '—'}</div>
    </div>`).join('');

  openModal(`Application — ${app.username}`, `
    <div style="max-height:60vh;overflow-y:auto">${answersHTML}</div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Close</button>
    </div>`);
}

loadApplications();
