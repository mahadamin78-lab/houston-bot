// Settings page — static config display
