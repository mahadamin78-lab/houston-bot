let allMembers = [];

async function loadMembers() {
  const tbody = document.getElementById('members-tbody');
  tbody.innerHTML = '<tr><td colspan="5"><div class="loading"><div class="spinner"></div>Fetching members...</div></td></tr>';
  try {
    allMembers = await api('GET', '/members');
    renderMembers();
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--danger);padding:20px">${e.message}</td></tr>`;
  }
}

function renderMembers() {
  const search = document.getElementById('member-search').value.toLowerCase();
  const tbody = document.getElementById('members-tbody');
  const filtered = allMembers.filter(m =>
    m.username.toLowerCase().includes(search) ||
    m.displayName.toLowerCase().includes(search) ||
    m.id.includes(search)
  );
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state"><h3>No members found</h3></div></td></tr>'; return; }
  tbody.innerHTML = filtered.map(m => `
    <tr>
      <td>
        <div class="member-cell">
          <img class="avatar" src="${m.avatar}" onerror="this.src='/images/logo.png'">
          <div class="member-info">
            <span class="member-name">${m.displayName}</span>
            <span class="member-id">${m.username} · ${m.id}</span>
          </div>
        </div>
      </td>
      <td>${m.roles.slice(0,4).map(r => `<span class="role-pill" style="background:${r.color}22;color:${r.color};border-color:${r.color}44">${r.name}</span>`).join('')}${m.roles.length > 4 ? `<span class="badge badge-gray">+${m.roles.length-4}</span>` : ''}</td>
      <td style="font-size:12px;color:var(--text-muted)">${m.joinedAt ? new Date(m.joinedAt).toLocaleDateString() : '—'}</td>
      <td><span class="badge ${m.points >= 15 ? 'badge-red' : m.points >= 8 ? 'badge-yellow' : 'badge-gray'}">${m.points} pts</span></td>
      <td>
        <div class="flex gap-2 flex-wrap">
          <button class="btn btn-warning btn-sm" onclick="warnMember('${m.id}','${m.username}')">Warn</button>
          <button class="btn btn-danger btn-sm" onclick="kickMember('${m.id}','${m.username}')">Kick</button>
          <button class="btn btn-danger btn-sm" onclick="banMember('${m.id}','${m.username}')">Ban</button>
          <button class="btn btn-info btn-sm" onclick="addRole('${m.id}','${m.username}')">+Role</button>
          <button class="btn btn-ghost btn-sm" onclick="removeRole('${m.id}','${m.username}')">-Role</button>
        </div>
      </td>
    </tr>`).join('');
}

async function warnMember(id, name) {
  openModal('Warn Member', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Warning <strong>${name}</strong> (+1 point)</p>
    <div class="form-group"><label class="form-label">Reason</label><input class="form-input" id="m-reason" placeholder="Reason for warning"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-warning" onclick="doWarn('${id}')">Warn</button>
    </div>`);
}

async function doWarn(id) {
  const reason = document.getElementById('m-reason').value;
  if (!reason) return toast('Enter a reason', 'error');
  try { await api('POST', `/members/${id}/warn`, { reason }); toast('Member warned', 'success'); closeModal(); loadMembers(); }
  catch (e) { toast(e.message, 'error'); }
}

async function kickMember(id, name) {
  openModal('Kick Member', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Kicking <strong>${name}</strong> (+2 points)</p>
    <div class="form-group"><label class="form-label">Reason</label><input class="form-input" id="m-reason" placeholder="Reason"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" onclick="doKick('${id}')">Kick</button>
    </div>`);
}

async function doKick(id) {
  const reason = document.getElementById('m-reason').value;
  if (!reason) return toast('Enter a reason', 'error');
  try { await api('POST', `/members/${id}/kick`, { reason }); toast('Member kicked', 'success'); closeModal(); loadMembers(); }
  catch (e) { toast(e.message, 'error'); }
}

async function banMember(id, name) {
  openModal('Ban Member', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Banning <strong>${name}</strong></p>
    <div class="form-group"><label class="form-label">Reason</label><input class="form-input" id="m-reason" placeholder="Reason"></div>
    <div class="form-group"><label class="form-label">Temp Ban Duration (minutes, leave empty for permanent)</label><input class="form-input" id="m-duration" type="number" placeholder="e.g. 1440 for 24h"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" onclick="doBan('${id}')">Ban</button>
    </div>`);
}

async function doBan(id) {
  const reason = document.getElementById('m-reason').value;
  const duration = document.getElementById('m-duration').value;
  if (!reason) return toast('Enter a reason', 'error');
  try { await api('POST', `/members/${id}/ban`, { reason, duration: duration ? parseInt(duration) : null }); toast('Member banned', 'success'); closeModal(); loadMembers(); }
  catch (e) { toast(e.message, 'error'); }
}

async function addRole(id, name) {
  let roles = [];
  try { roles = await api('GET', '/roles'); } catch (e) {}
  openModal('Add Role', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Add role to <strong>${name}</strong></p>
    <div class="form-group"><label class="form-label">Select Role</label>
      <select class="form-select" id="m-role">
        ${roles.map(r => `<option value="${r.id}">${r.name}</option>`).join('')}
      </select>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-success" onclick="doAddRole('${id}')">Add Role</button>
    </div>`);
}

async function doAddRole(id) {
  const roleId = document.getElementById('m-role').value;
  try { await api('POST', `/members/${id}/addrole`, { roleId }); toast('Role added', 'success'); closeModal(); loadMembers(); }
  catch (e) { toast(e.message, 'error'); }
}

async function removeRole(id, name) {
  let roles = [];
  try { roles = await api('GET', '/roles'); } catch (e) {}
  openModal('Remove Role', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Remove role from <strong>${name}</strong></p>
    <div class="form-group"><label class="form-label">Select Role</label>
      <select class="form-select" id="m-role">
        ${roles.map(r => `<option value="${r.id}">${r.name}</option>`).join('')}
      </select>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" onclick="doRemoveRole('${id}')">Remove Role</button>
    </div>`);
}

async function doRemoveRole(id) {
  const roleId = document.getElementById('m-role').value;
  try { await api('POST', `/members/${id}/removerole`, { roleId }); toast('Role removed', 'success'); closeModal(); loadMembers(); }
  catch (e) { toast(e.message, 'error'); }
}

document.getElementById('member-search').addEventListener('input', renderMembers);
loadMembers();
