let allMMs = [];

async function loadModMails() {
  try {
    allMMs = await api('GET', '/modmails');
    renderModMails();
  } catch(e) { toast(e.message, 'error'); }
}

function renderModMails() {
  const search = document.getElementById('mm-search').value.toLowerCase();
  const filter = document.getElementById('mm-filter').value;
  const tbody = document.getElementById('mm-tbody');
  const filtered = allMMs.filter(m => {
    const matchSearch = (m.userTag||'').toLowerCase().includes(search) || (m.userId||'').includes(search);
    const matchFilter = filter === 'all' || m.status === filter;
    return matchSearch && matchFilter;
  });
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state"><h3>No mod mails found</h3></div></td></tr>'; return; }
  tbody.innerHTML = filtered.map(m => `
    <tr>
      <td><div style="font-weight:600">${m.userTag||m.userId}</div><div style="font-size:11px;color:var(--text-muted)">${m.userId}</div></td>
      <td style="max-width:200px;font-size:13px">${(m.messages?.[0]?.message||'—').slice(0,60)}${m.messages?.[0]?.message?.length>60?'...':''}</td>
      <td style="font-size:12px;color:var(--text-muted)">${formatDate(m.date)}</td>
      <td><span class="badge ${m.status==='open'?'badge-green':'badge-gray'}">${m.status}</span></td>
      <td><span class="badge ${m.aiEnabled?'badge-blue':'badge-gray'}">${m.aiEnabled?'On':'Off'}</span></td>
      <td>
        <div class="flex gap-2">
          <button class="btn btn-info btn-sm" onclick="viewMM('${m.id}','${m.userTag}')">View</button>
          ${m.status==='open'?`<button class="btn btn-danger btn-sm" onclick="closeMM('${m.userId}')">Close</button>`:''}
        </div>
      </td>
    </tr>`).join('');
}

async function viewMM(id, tag) {
  try {
    const msgs = await api('GET', `/modmails/${id}/messages`);
    const html = msgs.length
      ? msgs.map(m => `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
          <div style="font-size:11px;color:${m.from==='staff'?'#22c55e':'#E8453C'};font-weight:600">${m.from==='staff'?'⬆ Staff':'⬇ User'} — ${m.authorTag} — ${formatDate(m.timestamp)}</div>
          <div style="font-size:13px;margin-top:3px">${m.message}</div>
        </div>`).join('')
      : '<div style="color:var(--text-muted);text-align:center;padding:20px">No messages</div>';
    openModal(`Mod Mail: ${tag}`, `<div style="max-height:400px;overflow-y:auto">${html}</div><div class="modal-footer"><button class="btn btn-ghost" onclick="closeModal()">Close</button></div>`);
  } catch(e) { toast(e.message,'error'); }
}

async function closeMM(userId) {
  const ok = await confirmModal('Close Mod Mail', '<p>Close this mod mail? The user will be notified.</p>');
  if (!ok) return;
  try { await api('POST', `/modmails/${userId}/close`); toast('Mod mail closed','success'); loadModMails(); }
  catch(e) { toast(e.message,'error'); }
}

document.getElementById('mm-search').addEventListener('input', renderModMails);
loadModMails();
