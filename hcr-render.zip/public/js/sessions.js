async function loadSessions() {
  try {
    const sessions = await api('GET', '/sessions');
    const el = document.getElementById('sessions-list');
    if (!sessions.length) { empty(el, 'No sessions created yet'); return; }
    el.innerHTML = sessions.map(s => `
      <div class="card" style="margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:start;flex-wrap:wrap;gap:12px">
          <div>
            <div style="font-size:16px;font-weight:700">${s.name}</div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px">ID: ${s.id} · Created ${formatDate(s.date)}</div>
            <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
              <span class="badge ${s.status === 'active' ? 'badge-green' : s.status === 'ended' ? 'badge-gray' : 'badge-yellow'}">${s.status}</span>
              ${s.boosted ? '<span class="badge badge-red">⚡ Boosted</span>' : ''}
              <span class="badge badge-blue">🗳 ${s.votes} votes</span>
            </div>
          </div>
          <div class="flex gap-2 flex-wrap">
            ${s.status === 'pending' ? `<button class="btn btn-info btn-sm" onclick="voteSession('${s.id}')">🗳 Vote</button>` : ''}
            ${s.status !== 'active' && s.status !== 'ended' ? `<button class="btn btn-success btn-sm" onclick="startSession('${s.id}')">▶ Start</button>` : ''}
            ${s.status === 'active' ? `<button class="btn btn-danger btn-sm" onclick="stopSession('${s.id}')">■ Stop</button>` : ''}
            ${s.status === 'active' && !s.boosted ? `<button class="btn btn-warning btn-sm" onclick="boostSession('${s.id}')">⚡ Boost</button>` : ''}
          </div>
        </div>
        ${s.startTime ? `<div style="font-size:12px;color:var(--text-muted);margin-top:8px">Started: ${formatDate(s.startTime)}${s.endTime ? ` · Ended: ${formatDate(s.endTime)}` : ''}</div>` : ''}
      </div>`).join('');
  } catch (e) { toast(e.message, 'error'); }
}

async function createSession() {
  openModal('Create Session', `
    <div class="form-group"><label class="form-label">Session Name</label><input class="form-input" id="sess-name" placeholder="e.g. Training Session #1"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="doCreate()">Create</button>
    </div>`);
}

async function doCreate() {
  const name = document.getElementById('sess-name').value;
  if (!name) return toast('Enter session name', 'error');
  try { await api('POST', '/sessions/create', { name }); toast('Session created!', 'success'); closeModal(); loadSessions(); }
  catch (e) { toast(e.message, 'error'); }
}

async function voteSession(id) {
  try { const r = await api('POST', `/sessions/${id}/vote`); toast(`Voted! Total: ${r.votes}`, 'success'); loadSessions(); }
  catch (e) { toast(e.message, 'error'); }
}

async function startSession(id) {
  try { await api('POST', `/sessions/${id}/start`); toast('Session started!', 'success'); loadSessions(); }
  catch (e) { toast(e.message, 'error'); }
}

async function stopSession(id) {
  const ok = await confirmModal('Stop Session', '<p>Stop this session? This will clear all session data.</p>');
  if (!ok) return;
  try { await api('POST', `/sessions/${id}/stop`); toast('Session stopped', 'success'); loadSessions(); }
  catch (e) { toast(e.message, 'error'); }
}

async function boostSession(id) {
  try { await api('POST', `/sessions/${id}/boost`); toast('Session boosted! ⚡', 'success'); loadSessions(); }
  catch (e) { toast(e.message, 'error'); }
}

loadSessions();
