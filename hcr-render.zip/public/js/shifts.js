async function loadShifts() {
  try {
    const shifts = await api('GET', '/shifts');
    const active = shifts.filter(s => s.active).length;
    document.getElementById('active-shifts').textContent = active;

    const myShift = shifts.find(s => s.userId === window.CURRENT_USER_ID);
    if (myShift) {
      document.getElementById('my-total').textContent = formatDuration(myShift.totalMinutes || 0);
      document.getElementById('my-weekly').textContent = formatDuration(myShift.weeklyMinutes || 0);
    } else {
      document.getElementById('my-total').textContent = '0m';
      document.getElementById('my-weekly').textContent = '0m';
    }

    const tbody = document.getElementById('shifts-tbody');
    if (!shifts.length) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state"><h3>No shift data</h3></div></td></tr>'; return; }
    tbody.innerHTML = shifts.map(s => `
      <tr>
        <td style="font-size:13px;font-family:monospace">${s.userId}</td>
        <td><span class="badge ${s.active ? 'badge-green' : 'badge-gray'}">${s.active ? '● Active' : 'Offline'}</span></td>
        <td>${formatDuration(s.weeklyMinutes || 0)}</td>
        <td>${formatDuration(s.totalMinutes || 0)}</td>
        <td>
          <div class="flex gap-2">
            <button class="btn btn-info btn-sm" onclick="addTime('${s.userId}')">+ Time</button>
            <button class="btn btn-warning btn-sm" onclick="suspendQuota('${s.userId}')">Suspend Quota</button>
          </div>
        </td>
      </tr>`).join('');
  } catch (e) { toast(e.message, 'error'); }
}

async function startShift() {
  try { await api('POST', '/shifts/start'); toast('Shift started!', 'success'); loadShifts(); }
  catch (e) { toast(e.message, 'error'); }
}

async function endShift() {
  try {
    const res = await api('POST', '/shifts/end');
    toast(`Shift ended! You logged ${formatDuration(res.minutes)}.`, 'success');
    loadShifts();
  } catch (e) { toast(e.message, 'error'); }
}

async function addTime(userId) {
  openModal('Add Shift Time', `
    <p style="margin-bottom:12px;color:var(--text-muted)">Ownership only — Add minutes to user shift.</p>
    <div class="form-group"><label class="form-label">Minutes to Add</label><input type="number" class="form-input" id="add-mins" placeholder="e.g. 60"></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="doAddTime('${userId}')">Add Time</button>
    </div>`);
}

async function doAddTime(userId) {
  const minutes = document.getElementById('add-mins').value;
  if (!minutes) return toast('Enter minutes', 'error');
  try { await api('POST', `/shifts/${userId}/add`, { minutes }); toast('Time added', 'success'); closeModal(); loadShifts(); }
  catch (e) { toast(e.message, 'error'); }
}

async function suspendQuota(userId) {
  const ok = await confirmModal('Suspend Weekly Quota', '<p>Suspend this week\'s quota for this staff member? (BOD/Ownership only)</p>');
  if (!ok) return;
  try { await api('POST', `/shifts/${userId}/suspend`); toast('Quota suspended for this week', 'success'); loadShifts(); }
  catch (e) { toast(e.message, 'error'); }
}

loadShifts();
