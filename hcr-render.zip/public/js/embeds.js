let fieldCount = 0;
let ddOptionCount = 0;

function toggleDropdown() {
  const enabled = document.getElementById('enable-dropdown').checked;
  document.getElementById('dropdown-section').style.display = enabled ? 'block' : 'none';
  document.getElementById('dropdown-preview').style.display = enabled ? 'block' : 'none';
  updatePreview();
}

function addDropdownOption() {
  const id = ++ddOptionCount;
  const container = document.getElementById('dd-options');
  const div = document.createElement('div');
  div.id = `dd-opt-${id}`;
  div.style.cssText = 'background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:8px';
  div.innerHTML = `
    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
      <span style="font-size:12px;font-weight:600;color:var(--text-muted)">Option ${id}</span>
      <button class="btn btn-danger btn-sm" onclick="removeOption(${id})">✕</button>
    </div>
    <div class="form-group"><input class="form-input" id="dd-label-${id}" placeholder="Label (e.g. Support)" oninput="updatePreview()"></div>
    <div class="form-group"><input class="form-input" id="dd-value-${id}" placeholder="Value (e.g. support) — optional"></div>
    <div class="form-group"><input class="form-input" id="dd-desc-${id}" placeholder="Description (optional)" oninput="updatePreview()"></div>
    <div class="form-group">
      <label class="form-label">Bot Reply Message</label>
      <textarea class="form-textarea" id="dd-reply-${id}" placeholder="What the bot sends when this option is selected..." style="min-height:60px"></textarea>
    </div>`;
  container.appendChild(div);
  updatePreview();
}

function removeOption(id) {
  document.getElementById(`dd-opt-${id}`)?.remove();
  updatePreview();
}

function addField() {
  const id = ++fieldCount;
  const container = document.getElementById('eb-fields');
  const div = document.createElement('div');
  div.id = `field-${id}`;
  div.style.cssText = 'background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:8px';
  div.innerHTML = `
    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
      <span style="font-size:12px;font-weight:600;color:var(--text-muted)">Field ${id}</span>
      <button class="btn btn-danger btn-sm" onclick="removeField(${id})">✕</button>
    </div>
    <div class="form-group"><input class="form-input" id="fn-${id}" placeholder="Field name" oninput="updatePreview()"></div>
    <div class="form-group"><input class="form-input" id="fv-${id}" placeholder="Field value" oninput="updatePreview()"></div>
    <label style="font-size:12px;color:var(--text-muted);display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="fi-${id}" onchange="updatePreview()"> Inline</label>`;
  container.appendChild(div);
  updatePreview();
}

function removeField(id) {
  document.getElementById(`field-${id}`)?.remove();
  updatePreview();
}

function updatePreview() {
  const title = document.getElementById('eb-title').value;
  const desc = document.getElementById('eb-desc').value;
  const color = document.getElementById('eb-color').value;
  const thumb = document.getElementById('eb-thumb').value;
  const banner = document.getElementById('eb-banner').value;
  const author = document.getElementById('eb-author').value;
  const footer = document.getElementById('eb-footer').value;

  const fields = [];
  for (let i = 1; i <= fieldCount; i++) {
    const fn = document.getElementById(`fn-${i}`);
    const fv = document.getElementById(`fv-${i}`);
    if (fn?.value) fields.push({ name: fn.value, value: fv?.value || '' });
  }

  const preview = document.getElementById('embed-preview');
  preview.style.borderLeftColor = color;
  preview.innerHTML = `
    ${author ? `<div style="font-size:12px;color:var(--text-muted);margin-bottom:6px">${author}</div>` : ''}
    ${thumb ? `<img src="${thumb}" style="float:right;width:60px;height:60px;border-radius:50%;object-fit:cover" onerror="this.style.display='none'">` : ''}
    ${title ? `<div style="font-weight:700;margin-bottom:6px;color:${color}">${title}</div>` : ''}
    ${desc ? `<div style="font-size:13.5px;color:var(--text-muted);white-space:pre-wrap">${desc}</div>` : ''}
    ${fields.map(f => `<div style="margin-top:10px"><div style="font-size:12px;font-weight:700">${f.name}</div><div style="font-size:13px;color:var(--text-muted)">${f.value}</div></div>`).join('')}
    ${banner ? `<img src="${banner}" style="margin-top:10px;max-width:100%;border-radius:6px" onerror="this.style.display='none'">` : ''}
    ${footer ? `<div style="font-size:11px;color:var(--text-muted);margin-top:10px;border-top:1px solid var(--border);padding-top:8px">${footer}</div>` : ''}`;

  // Update dropdown preview
  const ddEnabled = document.getElementById('enable-dropdown').checked;
  if (ddEnabled) {
    const placeholder = document.getElementById('dd-placeholder').value || 'Select an option...';
    document.getElementById('dd-preview-placeholder').textContent = placeholder;
    document.getElementById('dropdown-preview').style.display = 'block';
  }
}

function clearEmbed() {
  ['eb-title','eb-desc','eb-footer','eb-author','eb-thumb','eb-banner','eb-channel','dd-placeholder'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('eb-color').value = '#E8453C';
  document.getElementById('eb-fields').innerHTML = '';
  document.getElementById('dd-options').innerHTML = '';
  document.getElementById('enable-dropdown').checked = false;
  document.getElementById('dropdown-section').style.display = 'none';
  document.getElementById('dropdown-preview').style.display = 'none';
  fieldCount = 0;
  ddOptionCount = 0;
  updatePreview();
}

async function sendEmbed() {
  const channelId = document.getElementById('eb-channel').value;
  if (!channelId) return toast('Enter a channel ID', 'error');

  const fields = [];
  for (let i = 1; i <= fieldCount; i++) {
    const fn = document.getElementById(`fn-${i}`);
    const fv = document.getElementById(`fv-${i}`);
    const fi = document.getElementById(`fi-${i}`);
    if (fn?.value) fields.push({ name: fn.value, value: fv?.value || '\u200b', inline: fi?.checked || false });
  }

  const ddEnabled = document.getElementById('enable-dropdown').checked;
  let dropdown = null;
  if (ddEnabled) {
    const options = [];
    for (let i = 1; i <= ddOptionCount; i++) {
      const label = document.getElementById(`dd-label-${i}`)?.value;
      if (!label) continue;
      const value = document.getElementById(`dd-value-${i}`)?.value || label.toLowerCase().replace(/\s+/g,'_');
      const description = document.getElementById(`dd-desc-${i}`)?.value;
      const reply = document.getElementById(`dd-reply-${i}`)?.value;
      options.push({ label, value, description: description || undefined, reply: reply || undefined });
    }
    if (!options.length) return toast('Add at least one dropdown option', 'error');
    dropdown = { placeholder: document.getElementById('dd-placeholder').value || 'Select an option...', options };
  }

  const payload = {
    channelId,
    title: document.getElementById('eb-title').value,
    description: document.getElementById('eb-desc').value,
    color: document.getElementById('eb-color').value,
    footer: document.getElementById('eb-footer').value,
    authorName: document.getElementById('eb-author').value,
    thumbnail: document.getElementById('eb-thumb').value,
    banner: document.getElementById('eb-banner').value,
    fields,
    dropdown
  };

  try {
    await api('POST', '/embeds/send', payload);
    toast('Embed sent successfully! 🚀', 'success');
  } catch (e) { toast(e.message, 'error'); }
}

updatePreview();
