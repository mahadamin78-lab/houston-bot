let allInfractions = [];

async function loadInfractions() {
  try {
    allInfractions = await api('GET', '/infractions');
    renderInfractions();
  } catch (e) { toast(e.message, 'error'); }
}

function renderInfractions() {
  const search = document.getElementById('inf-search').value.toLowerCase();
  const tbody = document.getElementById('infractions-tbody');
  const filtered = allInfractions.filter(i =>
    (i.username || '').toLowerCase().includes(search) ||
    (i.userId || '').includes(search) ||
    (i.typeLabel || '').toLowerCase().includes(search)
  );
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="7"><div class="empty-state"><h3>No infractions found</h3></div></td></tr>'; return; }
  tbody.innerHTML = filtered.map(i => `
    <tr style="${i.revoked ? 'opacity:0.5' : ''}">
      <td><div style="font-weight:600">${i.username || i.userId}</div><div style="font-size:11px;color:var(--text-muted)">${i.userId}</div></td>
      <td><span class="badge ${getBadgeClass(i.type)}">${i.typeLabel}</span></td>
      <td style="max-width:180px;font-size:13px">${i.reason}</td>
      <td style="font-size:12px;color:var(--text-muted)">${i.issuedByTag || i.issuedBy}</td>
      <td style="font-size:12px;color:var(--text-muted)">${formatDate(i.date)}</td>
      <td><span class="badge ${i.revoked ? 'badge-gray' : 'badge-green'}">${i.revoked ? 'Revoked' : 'Active'}</span></td>
      <td>${!i.revoked ? `<button class="btn btn-danger btn-sm" onclick="revokeInfraction('${i.id}')">Revoke</button>` : '—'}</td>
    </tr>`).join('');
}

function getBadgeClass(type) {
  if (!type) return 'badge-gray';
  if (type.includes('termination') || type.includes('zerotolerance') || type.includes('suspension')) return 'badge-red';
  if (type.includes('strike')) return 'badge-yellow';
  return 'badge-blue';
}

async function revokeInfraction(id) {
  const ok = await confirmModal('Revoke Infraction', '<p>Are you sure you want to revoke this infraction?</p>');
  if (!ok) return;
  try { await api('POST', `/infractions/${id}/revoke`); toast('Infraction revoked', 'success'); loadInfractions(); }
  catch (e) { toast(e.message, 'error'); }
}

function openNewInfraction() {
  openModal('Issue Infraction', `
    <div class="form-group"><label class="form-label">User ID</label><input class="form-input" id="inf-uid" placeholder="Discord User ID"></div>
    <div class="form-group"><label class="form-label">Username</label><input class="form-input" id="inf-uname" placeholder="Username#0000"></div>
    <div class="form-group"><label class="form-label">Type</label>
      <select class="form-select" id="inf-type">
        <option value="warning1">Warning 1</option>
        <option value="warning2">Warning 2</option>
        <option value="strike1">Strike 1</option>
        <option value="strike2">Strike 2</option>
        <option value="suspension">Suspension</option>
        <option value="termination">Termination</option>
        <option value="zerotolerance">Zero Tolerance Policy</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Reason</label><textarea class="form-textarea" id="inf-reason" placeholder="Reason for infraction..."></textarea></div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-danger" onclick="submitInfraction()">Issue Infraction</button>
    </div>`);
}

async function submitInfraction() {
  const userId = document.getElementById('inf-uid').value;
  const username = document.getElementById('inf-uname').value;
  const type = document.getElementById('inf-type').value;
  const reason = document.getElementById('inf-reason').value;
  if (!userId || !reason) return toast('Fill all required fields', 'error');
  try {
    await api('POST', '/infractions', { userId, username, type, reason });
    toast('Infraction issued', 'success');
    closeModal();
    loadInfractions();
  } catch (e) { toast(e.message, 'error'); }
}

document.getElementById('inf-search').addEventListener('input', renderInfractions);
loadInfractions();
