let allTickets = [];

async function loadTickets() {
  try {
    allTickets = await api('GET', '/tickets');
    renderTickets();
  } catch (e) { toast(e.message, 'error'); }
}

function renderTickets() {
  const search = document.getElementById('ticket-search').value.toLowerCase();
  const filter = document.getElementById('ticket-filter').value;
  const tbody = document.getElementById('tickets-tbody');
  const filtered = allTickets.filter(t => {
    const matchSearch = t.name.toLowerCase().includes(search) || t.openedByTag?.toLowerCase().includes(search);
    const matchFilter = filter === 'all' || t.status === filter;
    return matchSearch && matchFilter;
  });
  if (!filtered.length) { tbody.innerHTML = '<tr><td colspan="6"><div class="empty-state"><h3>No tickets found</h3></div></td></tr>'; return; }
  tbody.innerHTML = filtered.map(t => `
    <tr>
      <td><div style="font-weight:600">${t.name}</div><div style="font-size:11px;color:var(--text-muted)">${t.id}</div></td>
      <td><span class="badge badge-blue">${t.categoryLabel}</span></td>
      <td style="font-size:12px">${t.openedByTag || t.openedBy}</td>
      <td style="font-size:12px;color:var(--text-muted)">${formatDate(t.date)}</td>
      <td><span class="badge ${t.status === 'open' ? 'badge-green' : 'badge-gray'}">${t.status}</span></td>
      <td><button class="btn btn-info btn-sm" onclick="viewMessages('${t.id}','${t.name}')">View Messages</button></td>
    </tr>`).join('');
}

async function viewMessages(id, name) {
  try {
    const msgs = await api('GET', `/tickets/${id}/messages`);
    const html = msgs.length
      ? msgs.map(m => `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
          <div style="font-size:11px;color:var(--text-muted)">${m.authorTag || m.authorId} — ${formatDate(m.timestamp)}</div>
          <div style="font-size:13px;margin-top:3px">${m.message}</div>
        </div>`).join('')
      : '<div style="color:var(--text-muted);text-align:center;padding:20px">No messages recorded</div>';
    openModal(`Ticket: ${name}`, `<div style="max-height:400px;overflow-y:auto">${html}</div><div class="modal-footer"><button class="btn btn-ghost" onclick="closeModal()">Close</button></div>`);
  } catch (e) { toast(e.message, 'error'); }
}

document.getElementById('ticket-search').addEventListener('input', renderTickets);
loadTickets();
