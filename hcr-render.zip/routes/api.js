const express = require('express');
const router = express.Router();
const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');
const store = require('../utils/store');
const { generateId, formatDate } = require('../utils/helpers');
const { getAIResponse } = require('../utils/aiHelper');

function ensureAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ error: 'Not authenticated' });
}

// ── Stats ─────────────────────────────────────────────
router.get('/stats', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    res.json({
      members: guild.memberCount,
      activeStaff: Array.from(store.shifts.values()).filter(s => s.active).length,
      openTickets: Array.from(store.tickets.values()).filter(t => t.status === 'open').length,
      activeSessions: Array.from(store.sessions.values()).filter(s => s.status === 'active').length
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Members ───────────────────────────────────────────
router.get('/members', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const members = await guild.members.fetch();
    res.json(members.map(m => ({
      id: m.id, username: m.user.username, displayName: m.displayName,
      avatar: m.user.displayAvatarURL({ size: 64 }),
      roles: m.roles.cache.filter(r => r.id !== guild.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor })),
      joinedAt: m.joinedAt,
      isStaff: config.STAFF_ROLES.some(rid => m.roles.cache.has(rid)),
      points: store.punishments.get(m.id)?.points || 0
    })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/members/:id/warn', ensureAuth, async (req, res) => {
  const { reason } = req.body;
  const userId = req.params.id;
  if (!store.punishments.has(userId)) store.punishments.set(userId, { points: 0, history: [] });
  const p = store.punishments.get(userId);
  p.points += 1;
  p.history.push({ type: 'warn', reason, by: req.user.id, date: Date.now() });
  try {
    const client = req.app.get('client');
    const user = await client.users.fetch(userId);
    await user.send(`⚠️ You have been **warned** in Houston City Roleplay.\nReason: ${reason}`).catch(() => {});
    if (p.points >= 20) {
      const guild = await client.guilds.fetch(config.GUILD_ID);
      await guild.bans.create(userId, { reason: 'Auto-ban: 20 punishment points' }).catch(() => {});
    }
  } catch (e) {}
  res.json({ success: true, points: p.points });
});

router.post('/members/:id/kick', ensureAuth, async (req, res) => {
  const { reason } = req.body;
  const userId = req.params.id;
  if (!store.punishments.has(userId)) store.punishments.set(userId, { points: 0, history: [] });
  const p = store.punishments.get(userId);
  p.points += 2;
  p.history.push({ type: 'kick', reason, by: req.user.id, date: Date.now() });
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = guild.members.cache.get(userId);
    if (member) { await member.send(`👢 You were **kicked** from HCR.\nReason: ${reason}`).catch(() => {}); await member.kick(reason); }
  } catch (e) {}
  res.json({ success: true, points: p.points });
});

router.post('/members/:id/ban', ensureAuth, async (req, res) => {
  const { reason, duration } = req.body;
  const userId = req.params.id;
  if (!store.punishments.has(userId)) store.punishments.set(userId, { points: 0, history: [] });
  const p = store.punishments.get(userId);
  p.points += duration ? 4 : 20;
  p.history.push({ type: duration ? 'tempban' : 'ban', reason, duration, by: req.user.id, date: Date.now() });
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = guild.members.cache.get(userId);
    if (member) await member.send(`🔨 You were **banned** from HCR.\nReason: ${reason}`).catch(() => {});
    await guild.bans.create(userId, { reason });
    if (duration) store.tempBans.set(userId, { expiresAt: Date.now() + duration * 60000 });
  } catch (e) {}
  res.json({ success: true });
});

router.post('/members/:id/addrole', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.params.id);
    const role = guild.roles.cache.get(req.body.roleId);
    if (!role) return res.status(404).json({ error: 'Role not found' });
    await member.roles.add(role);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/members/:id/removerole', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.params.id);
    const role = guild.roles.cache.get(req.body.roleId);
    if (!role) return res.status(404).json({ error: 'Role not found' });
    await member.roles.remove(role);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Infractions ───────────────────────────────────────
router.get('/infractions', ensureAuth, (req, res) => {
  const all = [];
  for (const [, list] of store.infractions) list.forEach(i => all.push(i));
  res.json(all.sort((a, b) => b.date - a.date));
});

router.post('/infractions', ensureAuth, async (req, res) => {
  const { userId, username, type, reason } = req.body;
  if (!userId || !reason) return res.status(400).json({ error: 'Missing fields' });
  if (!store.infractions.has(userId)) store.infractions.set(userId, []);
  const list = store.infractions.get(userId);
  const typeLabels = { warning1:'Warning 1', warning2:'Warning 2', strike1:'Strike 1', strike2:'Strike 2', suspension:'Suspension', termination:'Termination', zerotolerance:'Zero Tolerance Policy' };
  const hasZT = list.some(i => i.type === 'zerotolerance' && !i.revoked);
  let finalType = type;
  if (hasZT && (type.startsWith('warning') || type.startsWith('strike'))) finalType = 'suspension';
  const infraction = { id: generateId(), userId, username, type: finalType, typeLabel: typeLabels[finalType], reason, issuedBy: req.user.id, issuedByTag: req.user.username, date: Date.now(), revoked: false };
  list.push(infraction);
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const ch = guild.channels.cache.get(config.CHANNELS.INFRACTIONS_LOG);
    if (ch) {
      const embed = new EmbedBuilder().setTitle('Staff Infraction Issued').setColor('#E8453C').setImage(config.IMAGES.INFRACTIONS)
        .addFields({ name: 'Staff Member', value: `<@${userId}>`, inline: true }, { name: 'Type', value: infraction.typeLabel, inline: true }, { name: 'Reason', value: reason }, { name: 'Issued By', value: `<@${req.user.id}>`, inline: true }, { name: 'Date', value: formatDate(infraction.date), inline: true }).setTimestamp();
      await ch.send({ embeds: [embed] });
    }
  } catch (e) {}
  res.json({ success: true, infraction });
});

router.post('/infractions/:id/revoke', ensureAuth, (req, res) => {
  for (const [, list] of store.infractions) {
    const inf = list.find(i => i.id === req.params.id);
    if (inf) { inf.revoked = true; return res.json({ success: true }); }
  }
  res.status(404).json({ error: 'Not found' });
});

// ── Promotions ────────────────────────────────────────
router.get('/promotions', ensureAuth, (req, res) => res.json(store.promotions.sort((a, b) => b.date - a.date)));

router.post('/promotions/:id/revoke', ensureAuth, async (req, res) => {
  const promo = store.promotions.find(p => p.id === req.params.id);
  if (!promo) return res.status(404).json({ error: 'Not found' });
  promo.revoked = true;
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(promo.userId);
    const role = guild.roles.cache.get(promo.newRoleId);
    if (role) await member.roles.remove(role).catch(() => {});
    if (promo.oldRoles?.length) {
      for (const r of promo.oldRoles) {
        const oldRole = guild.roles.cache.get(r.id);
        if (oldRole) await member.roles.add(oldRole).catch(() => {});
      }
    }
  } catch (e) {}
  res.json({ success: true });
});

// ── LOA ───────────────────────────────────────────────
router.get('/loa', ensureAuth, (req, res) => res.json(Array.from(store.loaRequests.values())));

router.post('/loa', ensureAuth, async (req, res) => {
  const { reason, startDate, endDate } = req.body;
  if (!reason || !startDate || !endDate) return res.status(400).json({ error: 'Missing fields' });
  const loa = { id: generateId(), userId: req.user.id, username: req.user.username, reason, startDate, endDate, date: Date.now(), status: 'pending' };
  store.loaRequests.set(req.user.id, loa);
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const ch = guild.channels.cache.get(config.CHANNELS.LOA_REQUESTS);
    if (ch) {
      const embed = new EmbedBuilder().setTitle('LOA Request').setColor('#E8453C')
        .addFields({ name: 'Staff Member', value: `<@${req.user.id}>`, inline: true }, { name: 'Reason', value: reason }, { name: 'Start', value: startDate, inline: true }, { name: 'End', value: endDate, inline: true }).setTimestamp();
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`loa_approve_${req.user.id}`).setLabel('Approve LOA').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`loa_deny_${req.user.id}`).setLabel('Deny LOA').setStyle(ButtonStyle.Danger)
      );
      await ch.send({ embeds: [embed], components: [row] });
    }
  } catch (e) {}
  res.json({ success: true });
});

// ── Shifts ────────────────────────────────────────────
router.get('/shifts', ensureAuth, (req, res) => res.json(Array.from(store.shifts.entries()).map(([uid, s]) => ({ userId: uid, ...s }))));

router.post('/shifts/start', ensureAuth, (req, res) => {
  const uid = req.user.id;
  if (!store.shifts.has(uid)) store.shifts.set(uid, { active: false, totalMinutes: 0, weeklyMinutes: 0 });
  const s = store.shifts.get(uid);
  if (s.active) return res.status(400).json({ error: 'Shift already active' });
  s.active = true; s.startTime = Date.now();
  res.json({ success: true });
});

router.post('/shifts/end', ensureAuth, (req, res) => {
  const s = store.shifts.get(req.user.id);
  if (!s?.active) return res.status(400).json({ error: 'No active shift' });
  const mins = Math.floor((Date.now() - s.startTime) / 60000);
  s.active = false; s.totalMinutes = (s.totalMinutes || 0) + mins;
  s.weeklyMinutes = (s.weeklyMinutes || 0) + mins; s.startTime = null;
  res.json({ success: true, minutes: mins });
});

router.post('/shifts/:id/add', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.user.id);
    if (!member.roles.cache.has(config.ROLES.OWNERSHIP)) return res.status(403).json({ error: 'Ownership only' });
    if (!store.shifts.has(req.params.id)) store.shifts.set(req.params.id, { totalMinutes: 0, weeklyMinutes: 0 });
    const s = store.shifts.get(req.params.id);
    const mins = parseInt(req.body.minutes) || 0;
    s.totalMinutes = (s.totalMinutes || 0) + mins; s.weeklyMinutes = (s.weeklyMinutes || 0) + mins;
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/shifts/:id/suspend', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.user.id);
    if (!config.BOD_OWNERSHIP.some(r => member.roles.cache.has(r))) return res.status(403).json({ error: 'BOD/Ownership only' });
    if (!store.shifts.has(req.params.id)) store.shifts.set(req.params.id, { totalMinutes: 0, weeklyMinutes: 0 });
    store.shifts.get(req.params.id).suspended = true;
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Sessions ──────────────────────────────────────────
router.get('/sessions', ensureAuth, (req, res) => res.json(Array.from(store.sessions.values())));

router.post('/sessions/create', ensureAuth, (req, res) => {
  const session = { id: generateId(), name: req.body.name, votes: 0, voters: [], status: 'pending', boosted: false, startTime: null, endTime: null, createdBy: req.user.id, date: Date.now() };
  store.sessions.set(session.id, session);
  res.json({ success: true, session });
});

router.post('/sessions/:id/vote', ensureAuth, (req, res) => {
  const s = store.sessions.get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  if (s.voters.includes(req.user.id)) return res.status(400).json({ error: 'Already voted' });
  s.voters.push(req.user.id); s.votes++;
  if (s.votes >= 10 && s.status === 'pending') { s.status = 'auto-started'; s.startTime = Date.now(); }
  res.json({ success: true, votes: s.votes });
});

router.post('/sessions/:id/start', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.user.id);
    const s = store.sessions.get(req.params.id);
    if (!s) return res.status(404).json({ error: 'Not found' });
    if (!config.BOD_OWNERSHIP.some(r => member.roles.cache.has(r)) && s.votes < 10) return res.status(403).json({ error: 'Need 10 votes or BOD/Ownership' });
    s.status = 'active'; s.startTime = Date.now();
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/sessions/:id/stop', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.user.id);
    if (!config.BOD_OWNERSHIP.some(r => member.roles.cache.has(r))) return res.status(403).json({ error: 'BOD/Ownership only' });
    const s = store.sessions.get(req.params.id);
    if (!s) return res.status(404).json({ error: 'Not found' });
    s.status = 'ended'; s.endTime = Date.now();
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/sessions/:id/boost', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const member = await guild.members.fetch(req.user.id);
    if (!config.BOD_OWNERSHIP.some(r => member.roles.cache.has(r))) return res.status(403).json({ error: 'BOD/Ownership only' });
    const s = store.sessions.get(req.params.id);
    if (!s) return res.status(404).json({ error: 'Not found' });
    s.boosted = true;
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Tickets ───────────────────────────────────────────
router.get('/tickets', ensureAuth, (req, res) => res.json(Array.from(store.tickets.values()).sort((a, b) => b.date - a.date)));

router.get('/tickets/:id/messages', ensureAuth, (req, res) => {
  for (const [, t] of store.tickets) {
    if (t.id === req.params.id) return res.json(t.messages);
  }
  res.status(404).json({ error: 'Not found' });
});

// ── Embed Builder with Dropdown ───────────────────────
router.post('/embeds/send', ensureAuth, async (req, res) => {
  const { channelId, title, description, color, footer, authorName, thumbnail, banner, fields, dropdown } = req.body;
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'Channel not found' });

    const embed = new EmbedBuilder();
    if (title) embed.setTitle(title);
    if (description) embed.setDescription(description);
    if (color) embed.setColor(color);
    if (footer) embed.setFooter({ text: footer });
    if (authorName) embed.setAuthor({ name: authorName });
    if (thumbnail) embed.setThumbnail(thumbnail);
    if (banner) embed.setImage(banner);
    if (fields?.length) embed.addFields(fields.map(f => ({ name: f.name, value: f.value || '\u200b', inline: f.inline || false })));

    const components = [];

    // Add dropdown menu if configured
    if (dropdown && dropdown.options?.length) {
      const menuId = generateId();
      store.dropdownMenus.set(menuId, dropdown);

      const menu = new StringSelectMenuBuilder()
        .setCustomId(`custom_menu_${menuId}`)
        .setPlaceholder(dropdown.placeholder || 'Select an option...')
        .addOptions(dropdown.options.map(opt => ({
          label: opt.label,
          value: opt.value || opt.label.toLowerCase().replace(/\s+/g, '_'),
          description: opt.description || undefined,
        })));

      components.push(new ActionRowBuilder().addComponents(menu));
    }

    await channel.send({ embeds: [embed], components });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Roles ─────────────────────────────────────────────
router.get('/roles', ensureAuth, async (req, res) => {
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    res.json(guild.roles.cache.filter(r => r.name !== '@everyone').map(r => ({ id: r.id, name: r.name, color: r.hexColor })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});



// ── Applications ──────────────────────────────────────
router.get('/applications', ensureAuth, (req, res) => {
  res.json(store.applications.sort((a, b) => b.date - a.date));
});

router.post('/applications', ensureAuth, async (req, res) => {
  const { answers } = req.body;
  if (!answers) return res.status(400).json({ error: 'Missing answers' });

  const application = {
    id: generateId(),
    userId: req.user.id,
    username: req.user.username,
    answers,
    date: Date.now(),
    status: 'pending'
  };

  store.applications.push(application);

  // DM every user with Ownership role
  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const members = await guild.members.fetch();
    const ownershipRole = '1479794518810296371';
    const owners = members.filter(m => m.roles.cache.has(ownershipRole));

    const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

    const summaryLines = Object.values(answers).slice(0, 5).map((a, i) => 
      `**${i+1}. ${a.question}**\n${a.answer || '—'}`
    ).join('\n\n');

    for (const [, owner] of owners) {
      try {
        const embed = new EmbedBuilder()
          .setTitle('📋 New BOD Application')
          .setColor('#E8453C')
          .setDescription(`**Applicant:** <@${req.user.id}> (${req.user.username})\n\n${summaryLines}\n\n*...and ${Object.keys(answers).length - 5} more answers*`)
          .setFooter({ text: `Application ID: ${application.id}` })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`app_approve_${application.id}`).setLabel('Approve').setStyle(ButtonStyle.Success).setEmoji('✅'),
          new ButtonBuilder().setCustomId(`app_deny_${application.id}`).setLabel('Deny').setStyle(ButtonStyle.Danger).setEmoji('❌')
        );

        await owner.send({ embeds: [embed], components: [row] });
      } catch(e) {}
    }
  } catch(e) { console.error('Application DM error:', e.message); }

  res.json({ success: true });
});

// ── Mod Mail ──────────────────────────────────────────
router.get('/modmails', ensureAuth, (req, res) => {
  res.json(Array.from(store.modmails.values()).sort((a,b) => b.date - a.date));
});

router.get('/modmails/:id/messages', ensureAuth, (req, res) => {
  for (const [, mm] of store.modmails) {
    if (mm.id === req.params.id) return res.json(mm.messages);
  }
  res.status(404).json({ error: 'Not found' });
});

router.post('/modmails/:userId/close', ensureAuth, async (req, res) => {
  const mm = store.modmails.get(req.params.userId);
  if (!mm) return res.status(404).json({ error: 'Not found' });
  const { closeModMail } = require('../events/modmail');
  const client = req.app.get('client');
  await closeModMail(req.params.userId, mm, client, req.user.username);
  try {
    const user = await client.users.fetch(req.params.userId);
    await user.send('🔒 Your mod mail has been closed by staff. DM again anytime if you need help!');
  } catch(e){}
  res.json({ success: true });
});


// ── Website Applications ──────────────────────────────
router.post('/website-application', async (req, res) => {
  const { department, dept, answers } = req.body;
  if (!department || !answers) return res.status(400).json({ error: 'Missing data' });

  // Allow cross-origin requests from website
  res.header('Access-Control-Allow-Origin', '*');

  try {
    const client = req.app.get('client');
    const guild = await client.guilds.fetch(config.GUILD_ID);
    const channel = guild.channels.cache.get('1488288153977749585');
    if (!channel) return res.status(404).json({ error: 'Channel not found' });

    const appId = generateId();
    const deptColors = { hpd: '#1d4ed8', hcso: '#b45309', hsp: '#15803d' };
    const deptEmojis = { hpd: '👮', hcso: '⭐', hsp: '🚔' };

    // Store application
    const application = {
      id: appId,
      userId: null,
      username: answers['0_discord']?.answer || 'Unknown',
      department,
      dept,
      answers,
      date: Date.now(),
      status: 'pending'
    };
    store.applications.push(application);

    // Build full answers description
    const answerLines = Object.values(answers).map((a, i) =>
      `**${i+1}. ${a.question}**
${a.answer}`
    ).join('

');

    // Split if too long for one embed
    const chunks = [];
    let current = '';
    answerLines.split('

').forEach(line => {
      if ((current + '

' + line).length > 3800) {
        chunks.push(current);
        current = line;
      } else {
        current = current ? current + '

' + line : line;
      }
    });
    if (current) chunks.push(current);

    // Send first embed with buttons
    const embed = new EmbedBuilder()
      .setTitle(`${deptEmojis[dept] || '📋'} New ${department} Application`)
      .setColor(deptColors[dept] || '#E8453C')
      .setDescription(chunks[0] || 'No answers provided')
      .addFields({ name: 'Applicant', value: answers['0_discord']?.answer || 'Unknown', inline: true },
                 { name: 'Department', value: department, inline: true },
                 { name: 'Application ID', value: `\`${appId}\``, inline: false })
      .setFooter({ text: 'Submitted via HCR Website' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`webapp_approve_${appId}`).setLabel('Approve').setStyle(ButtonStyle.Success).setEmoji('✅'),
      new ButtonBuilder().setCustomId(`webapp_deny_${appId}`).setLabel('Deny').setStyle(ButtonStyle.Danger).setEmoji('❌')
    );

    await channel.send({ embeds: [embed], components: [row] });

    // Send extra chunks if answers are long
    for (let i = 1; i < chunks.length; i++) {
      const extraEmbed = new EmbedBuilder()
        .setColor(deptColors[dept] || '#E8453C')
        .setDescription(chunks[i])
        .setFooter({ text: `Continued — Application ${appId}` });
      await channel.send({ embeds: [extraEmbed] });
    }

    res.json({ success: true });
  } catch(e) {
    console.error('Website app error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// Handle CORS preflight
router.options('/website-application', (req, res) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  res.sendStatus(200);
});

module.exports = router;
