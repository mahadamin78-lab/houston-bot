const express = require('express');
const passport = require('passport');
const router = express.Router();

router.get('/login', passport.authenticate('discord'));
router.get('/callback', passport.authenticate('discord', { failureRedirect: '/?error=1' }), (req, res) => res.redirect('/dashboard'));
router.get('/logout', (req, res) => req.logout(() => res.redirect('/')));

module.exports = router;
