const express = require('express');
const router = express.Router();

function ensureAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/auth/login');
}

const pages = ['home','members','infractions','promotions','loa','shifts','tickets','sessions','modmail','applications','embeds','settings'];

pages.forEach(page => {
  router.get(page === 'home' ? ['/', '/home'] : `/${page}`, ensureAuth, (req, res) => {
    res.render('layout', { page, user: req.user, title: page.charAt(0).toUpperCase() + page.slice(1) });
  });
});

module.exports = router;
